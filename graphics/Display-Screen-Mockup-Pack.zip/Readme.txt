Hello and thankyou for downloading the Display Screen Mockup Pack.

To get started, open the PSD in Adobe Photoshop.

The general file is based around the smart-layers, found in the 'Screenshots' folder. Any changes you make to the screenshots in any of those 5 layers, will be reflected throughout the whole PSD. To edit the screenshots, double click on one of the layer thumbnails in the layers palate, which will bring open a new file window. Paste in your screenshot and transform it accordingly. Once you hit save, you can close the document and see your new changes.

Depending on which screenshot you edited will depend on which devices have changed:
	- Screenshot (Large): Covers the three iMac and the macbook
	- Screenshot (iPad Portrait): Covers three variations of the iPad in portrait view
	- Screenshot (iPad Landscape): Covers one variations in the iPad in portrait view
	- Screenshot (iPhone Portrait): Covers three variations of the iPhone in portrait view
	- Screenshot (iPhone Landscape): Covers one variations in the iPhone in portrait view

Of course, this comes in handy when you are wanting to display different content on different types of devices (for example, responsive layouts).

The first folder, 'Examples' contains 10 examples that have been created for you. You can simply copy and paste these into your project, or move them around to your liking first, cycling through each example to find the one you like the best.

The 'Mockups' folder contains all original devices. If you don't like the look of any of the examples, all of the devices that were made for this PSD have been put into that folder - so there should be something that you like.

Combining the mockups should provide a suitable method of displaying your showcase. The mockup sizes should be more than adequate for digital display.

***FAQ***

Is it possible to have multiple designs on copies of the same device?
Of course. Simply select the screenshot layer in the device folder that you want to replace, and delete it. Paste in your new screenshot, and click Layer > Create Clipping Mask. This will allow you to (for example), have 5 iPhones, each with different backgrounds.