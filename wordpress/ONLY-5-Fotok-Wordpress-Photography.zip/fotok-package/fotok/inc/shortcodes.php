<?php
/**
 * fotok Shortcodes
 *
 * @package fotok
 * @since fotok 1.0
 */

/**
 * TABLE OF CONTENTS:
 ***********************
 * 1.0 - Recent Posts
 * 2.0 - Portfolio
 * 3.0 - Dropcap
 * 4.0 - Slider
 * 5.0 - Columns
 * 6.0 - Buttons
 * 7.0 - Alerts
 * 8.0 - Icons
 * 9.0 - Highlights
 * 10.0 - Dividers
 ***********************
 */

/**
 * Remove <p></p> before and after the shortcode
 *
 * @since fotok 1.0
 */
function shortcode_empty_paragraph_fix($content){   
    $array = array (
        '<p>[' => '[', 
        ']</p>' => ']', 
        ']<br />' => ']'
    );

    $content = strtr($content, $array);

    return $content;
}
add_filter('the_content', 'shortcode_empty_paragraph_fix');

/**
 * 1.0 Recent Posts
 *
 * @since fotok 1.0
 */
function fotok_recent_posts_shortcode($atts, $content = null){
   	
   	extract(shortcode_atts(
   		array(
			'posts' => '3',
			'cat' => '',
		), 
	$atts));

	$loop = new WP_Query(
		array( 
			'orderby' => 'date', 
			'order' => 'DESC' , 
			'showposts' => $posts , 
			'cat' => $cat
		)
	);

	$list = '<h3 class="shortcode-content">' . $content . '</h3><div id="recent-posts"><div class="row clear">';

	if($loop->have_posts()) : while($loop->have_posts()) : $loop->the_post();

	$list .= '<div class="column-shortcode third"><a href="' . get_permalink() . '">' . get_the_post_thumbnail($post_id, 'shortcodes-thumb') . '</a><h2 class="recent-post-title"><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>' . '<div class="recent-posts-content">' . get_the_excerpt() . '</div><div class="recent-posts-meta">' . get_the_date() . '</div></div>';

	endwhile;
	
	wp_reset_query();
	
	return $list . '</div></div>';

	endif;

}
add_shortcode('recent-posts', 'fotok_recent_posts_shortcode');

/**
 * 2.0 Portfolio
 *
 * @since fotok 1.0
 */
function fotok_portfolio_shortcode($atts, $content = null){
   	
   	extract(shortcode_atts(
   		array(
			'items' => '3',
		), 
	$atts));

	$loop = new WP_Query(
		array( 
			'orderby' => 'date', 
			'order' => 'DESC' , 
			'showposts' => $items , 
			'post_type' => 'portfolio'
		)
	);

	$list = '<h3 class="shortcode-content">' . $content . '</h3><div id="portfolio-shortcode"><div id="masonry-loop" class="clear">';

	if($loop->have_posts()) : while($loop->have_posts()) : $loop->the_post();

	$list .= '<div class="masonry-entry"><div class="masonry-wrap"><a href="' . get_permalink() . '"><header><h2 class="portfolio-title">' . get_the_title() . '</h2></header><div class="masonry-thumb">' . get_the_post_thumbnail($post_id, 'shortcodes-thumb') . '</div></a></div></div>';

	endwhile;
	
	wp_reset_query();
	
	return $list . '</div></div>';

	endif;

}
add_shortcode('portfolio', 'fotok_portfolio_shortcode');

/**
 * 3.0 Dropcap
 *
 * @since fotok 1.0
 */
function fotok_dropcap_shortcode( $atts, $content = null ) {
	return '<span class="dropcap">' . $content . '</span>';
}
add_shortcode( 'dropcap', 'fotok_dropcap_shortcode' );

/**
 * 4.0 Slider
 *
 * @since fotok 1.0
 */
function fotok_responsive_slider($atts) {

	$slides = new WP_Query(
		array( 
			'orderby' => 'menu_order', 
			'order' => 'ASC' , 
			'post_type' => 'slides'
		)
	);

	$slider = '<div class="responsive-slider flexslider"><ul class="slides">';
	
	if($slides->have_posts()) : while($slides->have_posts()) : $slides->the_post();
				   
	$slider .= '<li><div id="slide-' . get_the_ID() . '" class="slide">';
						
	global $post;

		if ( has_post_thumbnail() ) {

			if ( get_post_meta( $post->ID, "_slide_link_url", true ) ) 
				$slider .= '<a href="' . get_post_meta( $post->ID, "_slide_link_url", true ) . '" title="' .  the_title_attribute ( array( 'echo' => 0 ) ) . '" >';

				$slider .= get_the_post_thumbnail( $post->ID, 'slide-thumbnail', array( 'class' => 'slide-thumbnail' ) );

			if ( get_post_meta( $post->ID, "_slide_link_url", true ) ) 
				$slider .= '</a>';

		}

	$slider .= '<h5 class="slide-title"><a href="' . get_post_meta( $post->ID, "_slide_link_url", true ) . '" title="' . the_title_attribute ( array( 'echo' => 0 ) ) . '" >' . get_the_title() . '</a></h5>';

	$slider .= '</div></li>';

	endwhile;

	wp_reset_query();

	return $slider . '</ul></div>';

	endif;
}
add_shortcode( 'slider', 'fotok_responsive_slider' );

/**
 * 5.0 Columns
 *
 * @since fotok 1.0
 */
function fotok_columns() {
	add_shortcode('row-start', 'fotok_row_start');
	add_shortcode('row-end', 'fotok_row_end');
	add_shortcode('half', 'fotok_half');
	add_shortcode('one-third', 'fotok_one_third');
	add_shortcode('two-thirds', 'fotok_two_thirds');
	add_shortcode('one-fourth', 'fotok_one_fourth');
	add_shortcode('three-fourths', 'fotok_three_fourths');
	add_shortcode('one-fifth', 'fotok_one_fifth');
	add_shortcode('four-fifths', 'fotok_four_fifths');
	add_shortcode('one-sixth', 'fotok_one_sixth');
	add_shortcode('five-sixths', 'fotok_five_sixths');
}
add_action( 'wp_head', 'fotok_columns' );

function fotok_row_start( $atts ) {
	return '<div class="row-shortcode clear">';
}

function fotok_row_end( $atts ) {
	return '</div>';
}

function fotok_half( $atts, $content = null ) {
	return '<div class="column half">' . do_shortcode($content) . '</div>';
}

function fotok_one_third( $atts, $content = null ) {
	return '<div class="column third">' . do_shortcode($content) . '</div>';
}

function fotok_two_thirds( $atts, $content = null ) {
	return '<div class="column two-thirds">' . do_shortcode($content) . '</div>';
}

function fotok_one_fourth( $atts, $content = null ) {
	return '<div class="column fourth">' . do_shortcode($content) . '</div>';
}

function fotok_three_fourths( $atts, $content = null ) {
	return '<div class="column three-fourths">' . do_shortcode($content) . '</div>';
}

function fotok_one_fifth( $atts, $content = null ) {
	return '<div class="column fifth">' . do_shortcode($content) . '</div>';
}

function fotok_four_fifths( $atts, $content = null ) {
	return '<div class="column four-fifths">' . do_shortcode($content) . '</div>';
}

function fotok_one_sixth( $atts, $content = null ) {
	return '<div class="column sixth">' . do_shortcode($content) . '</div>';
}

function fotok_five_sixths( $atts, $content = null ) {
	return '<div class="column five-sixths">' . do_shortcode($content) . '</div>';
}

/**
 * 6.0 Buttons
 *
 * @since fotok 1.0
 */
function fotok_button( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'url' => '#',
		'target' => '_self',
		'color' => 'grey',
		'size' => 'small',
		'type' => 'square',
		'display' => '',
		'title' => '',
		'class' => '',
		'rel' => ''
    ), $atts));
	
   return '<a target="'.$target.'" class="button '.$size.' '.$color.' '. $type .' '. $class .' '. $display .'" href="'.$url.'" title="' . $title . '" rel="' . $rel . '">' . do_shortcode($content) . '</a>';
}
add_shortcode('button', 'fotok_button');

/**
 * 7.0 Alerts
 *
 * @since fotok 1.0
 */
function fotok_alert( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'color' => 'grey',
		'type' => 'square',
		'text_align' => 'center',
		'width' => '100%'
    ), $atts));
	
   return '<div class="alert '.$color.' '. $type .' '. $text_align .'" style="width:'.$width.';">' . do_shortcode($content) . '</div>';
}
add_shortcode('alert', 'fotok_alert');

/**
 * 8.0 Icons
 *
 * @since fotok 1.0
 */
function fotok_icon( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'type' => '',
		'size' => '32px'
    ), $atts));
	
   return '<span class="genericon genericon-'.$type.'" style="font-size:'.$size.'; width:'.$size.'; height:'.$size.';">' . do_shortcode($content) . '</span>';
}
add_shortcode('icon', 'fotok_icon');

/**
 * 9.0 Highlights
 *
 * @since fotok 1.0
 */
function fotok_highlight( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'color'	=> 'grey',
		'class'	=> ''
	  ), $atts ));
	  return '<span class="highlight ' . $color . ' ' . $class . '">' . do_shortcode($content) . '</span>';

}
add_shortcode('highlight', 'fotok_highlight');

/**
 * 10.0 Dividers
 *
 * @since fotok 1.0
 */
function fotok_divider( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'color'	=> 'grey',
		'type'	=> 'solid',
		'width'	=> '100%',
		'class'	=> ''
	  ), $atts ));
	  return '<hr class="divider ' . $color . ' ' . $type . ' ' . $class . '" style="width:'.$width.';">' . do_shortcode($content) . '</span>';

}
add_shortcode('divider', 'fotok_divider');