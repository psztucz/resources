<?php
/**
 * The template used for displaying the Portfolio Content
 *
 * @package fotok
 * @since fotok 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('masonry-entry'); ?>>
	<div class="masonry-wrap">
		<a href='<?php the_permalink() ?>' rel='bookmark' title='<?php the_title(); ?>'>
			<header class="entry-header">
				<h2 class="portfolio-title"><?php the_title(); ?><h2>
			</header><!-- .entry-header -->

			<?php if ( has_post_thumbnail() && ! post_password_required() && ! is_attachment() ) : ?>
			<div class="masonry-thumb">
				<?php the_post_thumbnail('shortcodes-thumb'); ?>
			</div>
			<?php endif; ?>
		</a>
	</div><!-- .masonry-wrap -->
</article><!-- #post-## -->
