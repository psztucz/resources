<?php
/**
 * The Sidebar containing the Footer Sidebar
 *
 * @package fotok
 * @since fotok 1.0
 */
?>

	<?php
		if (   ! is_active_sidebar( 'footer-sidebar-1' )
			&& ! is_active_sidebar( 'footer-sidebar-2' )
			&& ! is_active_sidebar( 'footer-sidebar-3' )
			)
			return;
	?>

	<div id="footer-sidebar">
		<div class="row clear">
			<?php if ( is_active_sidebar( 'footer-sidebar-1' ) ) : ?>
				<div id="footer-sidebar-1" class="widget-area column third" role="complementary">
					<?php dynamic_sidebar( 'footer-sidebar-1' ); ?>
				</div><!-- .widget-area -->
			<?php endif; ?>

			<?php if ( is_active_sidebar( 'footer-sidebar-2' ) ) : ?>
				<div id="footer-sidebar-2" class="widget-area column third" role="complementary">
					<?php dynamic_sidebar( 'footer-sidebar-2' ); ?>
				</div><!-- .widget-area -->
			<?php endif; ?>

			<?php if ( is_active_sidebar( 'footer-sidebar-3' ) ) : ?>
				<div id="footer-sidebar-3" class="widget-area column third" role="complementary">
					<?php dynamic_sidebar( 'footer-sidebar-3' ); ?>
				</div><!-- .widget-area -->
			<?php endif; ?>
		</div>
	</div><!-- #footer-sidebar -->