<?php
/**
 * The template used for displaying single post
 *
 * @package fotok
 * @since fotok 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<div class="entry-meta">
			<?php fotok_posted_on(); ?>
		</div><!-- .entry-meta -->

		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
		
		<?php if ( has_post_thumbnail() && ! post_password_required() && ! is_attachment() ) : ?>
		<div class="entry-thumbnail">
			<?php the_post_thumbnail(); ?>
		</div>
		<?php endif; ?>
	</header><!-- .entry-header -->

	<div class="entry-content">
		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'fotok' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php if ( 'post' || 'portfolio' == get_post_type() ) : // Hide category and tag text for pages on Search ?>
			<?php
				/* translators: used between list items, there is a space after the comma */
				$categories_list = get_the_category_list( __( ', ', 'fotok' ) );
				if ( $categories_list ) :
			?>
			<span class="cat-links">
				<?php printf( __( 'Posted in %1$s', 'fotok' ), $categories_list ); ?>
			</span>
			<?php endif; // End if categories ?>

			<?php echo get_the_term_list( $post->ID, 'portfolio_category', '<span class="cat-links">Posted in ', ', ', '</span>' ); ?> 
			
			<?php
				/* translators: used between list items, there is a space after the comma */
				$tags_list = get_the_tag_list( '', __( ', ', 'fotok' ) );
				if ( $tags_list ) :
			?>
			<span class="tags-links">
				<?php printf( __( '/ Tagged %1$s', 'fotok' ), $tags_list ); ?>
			</span>
			<?php endif; // End if $tags_list ?>
		<?php endif; // End if 'post' == get_post_type() ?>

		<?php edit_post_link( __( 'Edit', 'fotok' ), '<span class="edit-link">', '</span>' ); ?>
		
		<div class="author-bio clear">
			<div class="author-avatar">
				<?php echo get_avatar( get_the_author_meta('email'), '90' ); ?>
			</div>
			<div class="author-info">
				<h4 class="author-title">
					<?php _e( 'Written by ', 'fotok' ); ?>
				    <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" rel="author">
                    	<?php printf( __( '%s', 'fotok' ), get_the_author() ); ?>
                	</a>
            	</h4>
				<p class="author-description"><?php the_author_meta('description'); ?></p>
				<p class="author-website"><?php _e( 'Website: ', 'fotok' ); ?><a href="<?php the_author_meta('user_url');?>"><?php the_author_meta('user_url');?></a></p>
				<ul class="author-icons">
					<?php 
						$rss_url = get_the_author_meta( 'rss_url' );
						if ( $rss_url && $rss_url != '' ) {
							echo '<li><a title="Feed" class="social social-feed" href="' . esc_url($rss_url) . '" target="' . __( '_blank', 'fotok' ) . '"></a></li>';
						}
						
						$google_profile = get_the_author_meta( 'google_profile' );
						if ( $google_profile && $google_profile != '' ) {
							echo '<li><a title="Google Plus" class="social social-googleplus" href="' . esc_url($google_profile) . '" rel="author" target="' . __( '_blank', 'fotok' ) . '"></a></li>';
						}
						
						$twitter_profile = get_the_author_meta( 'twitter_profile' );
						if ( $twitter_profile && $twitter_profile != '' ) {
							echo '<li><a title="Twitter" class="social social-twitter" href="' . esc_url($twitter_profile) . '" target="' . __( '_blank', 'fotok' ) . '"></a></li>';
						}
						
						$facebook_profile = get_the_author_meta( 'facebook_profile' );
						if ( $facebook_profile && $facebook_profile != '' ) {
							echo '<li><a title="Facebook" class="social social-facebook" href="' . esc_url($facebook_profile) . '" target="' . __( '_blank', 'fotok' ) . '"></a></li>';
						}
						
						$linkedin_profile = get_the_author_meta( 'linkedin_profile' );
						if ( $linkedin_profile && $linkedin_profile != '' ) {
							echo '<li><a title="Linkedin" class="social social-linkedin" href="' . esc_url($linkedin_profile) . '" target="' . __( '_blank', 'fotok' ) . '"></a></li>';
						}
					?>
				</ul>
			</div>
		</div><!-- .author-bio -->

		<?php get_template_part('share'); ?>
		
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->
