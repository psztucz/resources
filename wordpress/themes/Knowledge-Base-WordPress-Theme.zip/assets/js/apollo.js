function scaleToFill() {
    jQuery('video.video-background').each(function(index, videoTag) {
       var jQueryvideo = jQuery(videoTag),
           videoRatio = videoTag.videoWidth / videoTag.videoHeight,
           tagRatio = jQueryvideo.width() / jQueryvideo.height(),
           val;
        
       if (videoRatio < tagRatio) {
           val = tagRatio / videoRatio * 1.02; <!-- size increased by 2% because value is not fine enough and sometimes leaves a couple of white pixels at the edges -->
       } else if (tagRatio < videoRatio) {
           val = videoRatio / tagRatio * 1.02;
       }
       
       jQueryvideo.css('transform','scale(' + val  + ',' + val + ')');

    });    
}

jQuery(function () {
    scaleToFill();
    
    jQuery('.video-background').on('loadeddata', scaleToFill);
    
    jQuery(window).resize(function() {
        scaleToFill();
    });
});

jQuery(document).ready(function() {
  jQuery(function() {
    jQuery('.menu').tinyNav({
      'active' : 'current-menu-item', // String: Set the "active" class
      'activeSelected' : true, // Boolean: Whether or not the active item should be selected
      'header' : '- Navigation -', // String: Specify text for "header" 
    }); 
  });
});