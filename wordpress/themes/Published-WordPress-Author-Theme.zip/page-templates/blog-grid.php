<?php

/**
 * Template Name: Blog Grid Template
 */
 
get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">

		<?php 
			$args = array( 'post_type' => 'post', 'posts_per_page' => 99 );
			$loop = new WP_Query( $args ); 
			while ( $loop->have_posts() ) : $loop->the_post();  
		?>
			
		<div class="mason grid_2">
			<?php if ( has_post_thumbnail() ) {
					echo '<div class="post-thumbnail">';
					the_post_thumbnail();
					echo '</div>';
				} 
			?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<header class="entry-header">
					<h4 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h4>
				</header><!-- .entry-header -->

				<?php if ( is_search() ) : // Only display Excerpts for Search ?>
					<div class="entry-summary">
						<?php the_excerpt(); ?>
					</div><!-- .entry-summary -->
				<?php else : ?>
					<div class="entry-content">
						<?php if(show_full_posts()) { the_content(); } else the_excerpt(); ?>
						<?php
							wp_link_pages( array(
								'before' => '<div class="page-links">' . __( 'Pages:', 'base' ),
								'after'  => '</div>',
							) );
						?>
					</div><!-- .entry-content -->
				<?php endif; ?>

			</article><!-- #post-## -->
		</div>
		
		<?php endwhile; ?>

	</main><!-- #main -->
</div><!-- #primary -->

<?php get_footer(); ?>
