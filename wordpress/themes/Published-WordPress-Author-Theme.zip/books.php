<?php

/**

 * Template Name: Books Page

 */



get_header(); ?>




		<div id="books-page" >
		<div class="grid_6 intro">
			<?php while ( have_posts() ) : the_post(); ?>
			<h1><?php the_title(); ?></h1>

			<?php the_content() ?>
			<?php endwhile; // end of the loop. ?>

		</div>

	<?php wp_reset_query(); $args = array( 'post_type' => 'book', 'posts_per_page' => 99 );
	$loop = new WP_Query( $args );
	while ( $loop->have_posts() ) : $loop->the_post(); ?>
		
		<div class="grid_3 book">
			<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('book-thumb'); ?></a>

			<h4><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h4>

			<?php the_excerpt(); ?>

	
		</div>
<?php endwhile;  ?>
				<div class="clear"></div>

</div>





<?php get_footer(); ?>

