<header id="masthead" class="site-header" role="banner">
	<div class="grid overflow">
			<div class="site-branding col-5-12">
				<?php if( $logo = get_theme_mod('logo_upload') ) : ?>

					<a href="<?php echo home_url(); ?>"><img src="<?php echo esc_url($logo) ?>"></a>

				<?php else : ?>

					<?php if ( is_front_page() && is_home() ) : ?>
						<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
					<?php else : ?>
						<div class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></div>
					<?php endif;
					$description = get_bloginfo( 'description' );
					if ( ! empty( $description ) ) : ?>
						<div class="divider">&#124;</div>
						<div class="site-description"><?php echo esc_html( $description ); ?></div>
					<?php endif; ?>

				<?php endif;?>

			</div>

			<nav id="site-navigation" class="main-navigation  col-7-12" role="navigation">
				<?php wp_nav_menu( array( 'theme_location'=>'primary', 'depth'  => 1 ) ); ?>
			</nav>
	</div>
</header>