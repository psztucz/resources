<?php
/**
 * The template for displaying the footer.
 *
 * @package fotok
 * @since fotok 1.0
 */
?>

			</div><!-- #content -->

			<?php get_sidebar(); ?>

			<footer id="colophon" class="site-footer" role="contentinfo">

				<div class="site-info">

					<?php if ( get_theme_mod( 'fotok_footer' ) ) : ?>
						
						<?php echo get_theme_mod( 'fotok_footer' ); ?>
					
					<?php else : ?>
						
						<a href="<?php echo esc_url( __( 'http://wordpress.org/', 'fotok' ) ); ?>"><?php printf( __( 'Proudly powered by %s', 'fotok' ), 'WordPress' ); ?></a>
						<span class="sep"> | </span>
						<a href="<?php echo esc_url( __( 'http://pankogut.com/', 'fotok' ) ); ?>" rel="designer"><?php printf( __( 'Theme: %1$s by %2$s.', 'fotok' ), 'fotok', 'pankogut' ); ?></a>
					
					<?php endif; ?>

				</div><!-- .site-info -->
				
			</footer><!-- #colophon -->

		</div><!-- #site-right -->

	</div><!-- .container -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
