<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package apollo
 */
?>

	</div><!-- #content -->
	
	<?php get_template_part( 'partials/callout' ); ?>
	
	<?php if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) ) : ?>
		<footer id="colophon" class="footer" role="contentinfo">
			<div class="grid">
					<div class="footer-widget-1 col-5-12">
						<?php dynamic_sidebar( 'footer-1' ); ?>
					</div>
					<div class="footer-widget-2 col-2-12 push-3-12">
						<?php dynamic_sidebar( 'footer-2' ); ?>
					</div>
					<div class="footer-widget-3 col-2-12">
						<?php dynamic_sidebar( 'footer-3' ); ?>
					</div>
			</div><!-- .site-info -->
		</footer><!-- #colophon -->
	<?php endif; ?>

	<div class="sub-footer">
		<div class="grid">

			<p>Powered by the <a href="<?php echo THEME_URL ?>">Apollo Theme</a></p>

		</div><!-- .site-info -->
	</div><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
