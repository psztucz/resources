<?php 

/**
 * Initialize the options before anything else. 
 */

add_action( 'admin_init', 'custom_theme_options', 1 );

/**
 * Build the custom settings & update OptionTree.
 */
function custom_theme_options() {
  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( 'option_tree_settings', array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  $custom_settings = array(
    'contextual_help' => array(
      'content'       => array( 
        array(
          'id'        => 'general_help',
          'title'     => 'General Settings',
          'content'   => '<p>Interesting</p>'
        ),				
		  
		array(
			'id'        => 'home_help',
			'title'     => 'Home Settings',
			'content'   => '<p>Help content goes here!</p>'
		),				
		  
		array(
          'id'        => 'design_help',
          'title'     => 'Design Settings',
          'content'   => '<p>Help content goes here!</p>'
        ),		
		  
		array(
          'id'        => 'typography_help',
          'title'     => 'Typography Settings',
          'content'   => '<p>Help content goes here!</p>'
        ),				
		  
		 array(
			 'id'        => 'social_help',
			 'title'     => 'Social Settings',
			 'content'   => '<p>Help content goes here!</p>'
		 )
		  
      ),
      'sidebar'       => '<p>Sidebar content goes here!</p>',
    ),
    'sections'        => array(
		array(
			'id'          => 'general',
			'title'       => __( 'General Settings', 'ot-published' )
		),
		array(
			'id'          => 'home', 
			'title'       => __( 'Homepage Settings', 'ot-published' )
		),	  
		array(
			'id'          => 'design',
			'title'       => __( 'Design Settings', 'ot-published' )
		),	  
		array(
			'id'          => 'typography',
			'title'       => __( 'Typography Settings', 'ot-published' )
		),

		array(
			'id'          => 'social',
			'title'       => __( 'Social Settings', 'ot-published' )
		),
		
		array(
			'id'          => 'retailer_options',
			'title'       => __( 'Retailer Options', 'ot-published' )
		)
    ),
    'settings'        => array(
	  array(
        'id'          => 'logo_upload',
        'label'       => __( 'Custom Logo', 'ot-published'),
        'desc'        => __( 'Upload your logo.', 'ot-published'),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'favicon_upload',
        'label'       => __( 'Custom Favicon', 'ot-published'),
        'desc'        => __( 'Upload your favicon.', 'ot-published'),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),	  		 

		array( 
        'id'          => 'show_home_header_intro',
        'label'       => __( 'Display text in homepage header?', 'ot-author' ),
        'desc'        => __( 'Open a new browser window or tab when retailer links are clicked.' ),
        'std'         => 'on',
        'type'        => 'on-off',
        'section'     => 'home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),				
		
		array(
		  'id'          => 'home_header_intro',
		  'label'       => __( 'Homepage Header Introduction.', 'ot-published'),
		  'desc'        => __( 'This will be shown on just the homepage.', 'ot-published'),
		  'std'         => '',
		  'type'        => 'text',
		  'section'     => 'home',
		  'rows'        => '',
		  'post_type'   => '',
		  'taxonomy'    => '',
		  'min_max_step'=> '',
		  'class'       => '',
		  'condition'   => 'show_home_header_intro:is(on)',
		  'operator'    => 'and'      
		),

		array( 
        'id'          => 'show_header_intro',
        'label'       => __( 'Display text below header?', 'ot-author' ),
        'desc'        => '',
        'std'         => 'on',
        'type'        => 'on-off',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),		
		
		array(
			'id'          => 'header_intro',
			'label'       => __( 'Below Header Text', 'ot-published'),
			'desc'        => __( 'This will be shown on all pages except the home page.', 'ot-published'),
			'std'         => '',
			'type'        => 'text',
			'section'     => 'general',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '', 
			'condition'   => 'show_header_intro:is(on)', 
			'operator'    => 'and'
		),	  
      
      array(
        'id'          => 'excerpt_select',
        'label'       => __( 'Blog Content', 'ot-published'),
        'desc'        => __( 'Show full posts or excerpts on the blog?', 'ot-published'),
        'std'         => '',
        'type'        => 'select',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array( 
          array(
            'value'       => 'excerpts',
            'label'       => __( 'Excerpts', 'ot-published'),
            'src'         => ''
          ),
          array(
            'value'       => 'full',
            'label'       => __( 'Full Content', 'ot-published'),
            'src'         => ''
          )
        )
      ),
        
      array(
        'id'          => 'custom_css',
        'label'       => __( 'Custom CSS', 'ot-published'),
        'desc'        => __( 'Place any CSS code here.', 'ot-published'),
        'std'         => '',
        'type'        => 'css',
        'section'     => 'general',
        'rows'        => '15',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'analytics_code',
        'label'       => __( 'Analytics Code', 'ot-published'),
        'desc'        => __( 'Place any tracking/analytics code here.', 'ot-published'),
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'general',
        'rows'        => '15',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),	  
      array(
        'id'          => 'accent_color',
        'label'       => __( 'Accent Color', 'ot-published'),
        'desc'        => __( 'The accent color controls the color of all hyperlinks and buttons.', 'ot-published'),
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'design',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'header_color',
        'label'       => __( 'Header Background Color', 'ot-published'),
        'desc'        => __( 'Choose a background color for your header.', 'ot-published'),
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'design',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'footer_color',
        'label'       => __( 'Footer Background Color', 'ot-published'),
        'desc'        => __( 'Choose a background color for your footer.', 'ot-published'),
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'design',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'paragraph_font',
        'label'       => __( 'Base Font Style', 'ot-published'),
        'desc'        => __( 'Overwrite the default typography.', 'ot-published'),
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'title_font',
        'label'       => __( 'Post Title Font Style', 'ot-published'),
        'desc'        => __( 'Overwrite the default heading typography.', 'ot-published'), 
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),	  
	  array(
        'id'          => 'sidebar_heading',
        'label'       => __( 'Sidebar Heading Font Style', 'ot-published'),
        'desc'        => __( 'Overwrite the default sidebar typography.', 'ot-published'),
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'sidebar_font',
        'label'       => __( 'Sidebar Font Style', 'ot-published'),
        'desc'        => __( 'Overwrite the default sidebar typography.', 'ot-published'),
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),	  
	  array(
        'id'          => 'navigation_font',
        'label'       => __( 'Navigation Font Style', 'ot-published'),
        'desc'        => __( 'Overwrite the default navigation typography.', 'ot-published'),
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
		
		array( 
        'id'          => 'show_home_header_intro',
        'label'       => __( 'Display Home Page Header Text?', 'ot-published' ),
        'desc'        => '',
        'std'         => 'on',
        'type'        => 'on-off',
        'section'     => 'home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),	
		
		array( 
			'id'          => 'show_home_books',
			'label'       => __( 'Display Books Section?', 'ot-published' ),
			'desc'        => '',
			'std'         => 'on',
			'type'        => 'on-off',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		  ),	
		
		array(
			'id'          => 'home_books_intro',
			'label'       => __( 'Books Introduction Title', 'ot-published'),
			'desc'        => __( 'A title to introduce your books.', 'ot-published'),
			'std'         => 'Recently Published Books.',
			'type'        => 'text',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => 'show_home_books:is(on)',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'home_books_description',
			'label'       => __( 'Books Introduction', 'ot-published'),
			'desc'        => __( '100 words or less introducing your books.', 'ot-published'),
			'std'         => '',
			'type'        => 'textarea-simple',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '', 
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => 'show_home_books:is(on)',
			'operator'    => 'and'      ),

		array( 
			'id'          => 'show_home_blogs',
			'label'       => __( 'Display Blog Posts Section?', 'ot-published' ),
			'desc'        => '',
			'std'         => 'on',
			'type'        => 'on-off',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		  ),			
		
		array(
			'id'          => 'home_blogs_intro',
			'label'       => __( 'Blog Introduction Title', 'ot-published'),
			'desc'        => __( 'A title to introduce your log posts.', 'ot-published'),
			'std'         => 'Latest Blog Posts.',
			'type'        => 'text',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => 'show_home_blogs:is(on)',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'home_blogs_description',
			'label'       => __( 'Blog Introduction', 'ot-published'),
			'desc'        => __( '100 words or less introducing your blog posts.', 'ot-published'),
			'std'         => '',
			'type'        => 'textarea-simple',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => 'show_home_blogs:is(on)',
			'operator'    => 'and'
		),

		array( 
			'id'          => 'show_home_author',
			'label'       => __( 'Display Author Section?', 'ot-published' ),
			'desc'        => '',
			'std'         => 'on',
			'type'        => 'on-off',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		  ),			
		
		array(
			'id'          => 'home_author_image',
			'label'       => __( 'Author Image', 'ot-published'),
			'desc'        => __( 'This will automatically be transformed into a circular image. <br><br>Recommended size: 150px x 150px', 'ot-published'),
			'std'         => '',
			'type'        => 'upload',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '', 
			'min_max_step'=> '', 
			'class'       => '',
			'condition'   => 'show_home_author:is(on)',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'home_author_intro', 
			'label'       => __( 'Author Introduction Title', 'ot-published'),
			'desc'        => __( 'The title of your introduction.', 'ot-published'),
			'std'         => __( 'About the Author', 'ot-published'),
			'type'        => 'text',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '', 
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => 'show_home_author:is(on)',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'home_author_description',
			'label'       => __( 'Author Introduction', 'ot-published'),
			'desc'        => __( 'Use this area to introduce yourself and your work.', 'ot-published'),
			'std'         => '',
			'type'        => 'textarea-simple',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => 'show_home_author:is(on)',
			'operator'    => 'and'
		),
		array( 
        'id'          => 'show_sharing_buttons',
        'label'       => __( 'Display Facebook, Twitter and Google+ sharing buttons below posts?', 'ot-published' ),
        'desc'        => '',
        'std'         => 'on',
        'type'        => 'on-off',
        'section'     => 'social',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),			
		array(
			'id'          => 'twitter_url',
			'label'       => __( 'Twitter URL', 'ot-published'),
			'desc'        => '',
			'std'         => '', 
			'type'        => 'text', 
			'section'     => 'social',
			'rows'        => '', 
			'post_type'   => '',  
			'taxonomy'    => '',    
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'facebook_url',
			'label'       => __( 'Facebook URL', 'ot-published'),
			'desc'        => '',
			'std'         => '',
			'type'        => 'text',
			'section'     => 'social',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'google_url',
			'label'       => __( 'Google+ URL', 'ot-published'),
			'desc'        => '',
			'std'         => '',
			'type'        => 'text', 
			'section'     => 'social',
			'rows'        => '', 
			'post_type'   => '', 
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'pinterest_url',
			'label'       => __( 'Pinterest URL', 'ot-published'),
			'desc'        => '',
			'std'         => '',
			'type'        => 'text',
			'section'     => 'social',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			  'id'          => 'linkedin_url',
			  'label'       => __( 'LinkedIn URL', 'ot-published'),
			  'desc'        => '',
			  'std'         => '',
			  'type'        => 'text',
			  'section'     => 'social',
			  'rows'        => '',
			  'post_type'   => '',
			  'taxonomy'    => '',
			  'min_max_step'=> '',
			  'class'       => '',
			  'condition'   => '',
			  'operator'    => 'and'
			 ),
			
		array(
			'id'          => 'youtube_url',
			'label'       => __( 'YouTube URL', 'ot-published'),
			'desc'        => '', 
			'std'         => '',
			'type'        => 'text',
			'section'     => 'social',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'instagram_url',
			'label'       => __( 'Instagram URL', 'ot-published'),
			'desc'        => '',
			'std'         => '', 
			'type'        => 'text',
			'section'     => 'social',
			'rows'        => '', 
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '', 
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'rss_url',
			'label'       => __( 'RSS URL', 'ot-published'),
			'desc'        => '',
			'std'         => '',
			'type'        => 'text',
			'section'     => 'social',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),

	   array(
			'id'          => 'retailers',
			'label'       => __( 'Books Retailers', 'ot-published' ),
			'desc'        => __( 'Add the locations your books are available.', 'ot-published'),
			'std'         => '',
			'type'        => 'list-item',
			'section'     => 'retailer_options',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and',
			'settings'    => array( 
			  array(
				'id'          => 'retailer_name',
				'label'       => __( 'Retailer Name', 'ot-published' ),
				'desc'        => __( 'This will be shown on your book pages.', 'ot-published'),
				'std'         => '',
				'type'        => 'text',
				'post_type'   => '',
				'taxonomy'    => '',
				'min_max_step'=> '',
				'class'       => '',
				'condition'   => '',
				'operator'    => 'and'
			  ),
			   array(
				'id'          => 'retailer_id',
				'label'       => __( 'Retailer ID', 'ot-published' ),
				'desc'        => __( 'For backend use only. Choose a lowercase id consisting only of letters. Example: amazon', 'ot-published'),
				'std'         => '',
				'type'        => 'text',
				'post_type'   => '',
				'taxonomy'    => '',
				'min_max_step'=> '',
				'class'       => '',
				'condition'   => '',
				'operator'    => 'and'
			  )
			) 
		  )		
    )
  );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( 'option_tree_settings', $custom_settings ); 
  }
  
}