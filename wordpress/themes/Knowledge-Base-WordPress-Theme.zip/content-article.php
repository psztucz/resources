<?php
/**
 * @package apollo
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
	
		<?php if( is_single() ) : ?>
		
			<div class="article-title"><?php the_title( '<h1 class="entry-title">', '</h1>' ); ?></div>
		<div class="print-icon"><a href="#" onclick="window.print(); return false;"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/printer-icon.png" alt="print this page button" /></a></div>
		
		<?php else : ?>
		
			<div class="article-title-list"><?php the_title( sprintf( '<h5 class="taxonomy-archive-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h5>' ); ?></div>

		<?php endif; ?>
		
		<div class="clear"></div>
	</header><!-- .entry-header -->

	<?php if( is_single() ) : ?>	
	
	<div class="entry-content">
		
		<?php the_content(); ?>
		 
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'ot-apollo' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->
	
	<?php endif; ?>
	
</article><!-- #post-## -->
