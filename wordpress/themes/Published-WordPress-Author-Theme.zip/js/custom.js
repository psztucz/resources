jQuery(document).ready(function() {
  jQuery(function() {
       jQuery('.menu').tinyNav({
		header: '- Navigation -' // Writing any title with this option triggers the header
   });
	
  });
  jQuery('.back-to-top').click(function(event) {
    event.preventDefault();
    jQuery('html, body').animate({
      scrollTop: 0
    }, 2000);
    return false;
  });

}); 