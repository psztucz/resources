<?php
/**
 * The sidebar shown on knowledge base pages.
 *
 * @package apollo
 */

if ( ! is_active_sidebar( 'sidebar-2' ) ) {
	return;
}
?>
<div id="secondary" class="widget-area col-4-12" role="complementary">
	<?php dynamic_sidebar( 'sidebar-2' ); ?>
</div><!-- #secondary -->

</div>