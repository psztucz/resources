<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<h1 class="entry-title"><?php the_title(); ?></h1>

		<div class="entry-meta">
			<?php published_posted_on(); ?>
		</div><!-- .entry-meta -->
	</header><!-- .entry-header -->

	<div class="entry-content">
		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'ot-published' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

	<?php if( ot_get_option('show_sharing_buttons') != 'off' ) : ?>
	
		<div id="share-buttons">
			<div class="social-wide-button"><a target=_blank href="http://twitter.com/home?status=<?php the_title(); ?> - <?php the_permalink(); ?>" class="pure-button twitter-wide-button"><span class="socicon socicon-twitter"></span> Share on Twitter</a></div>
			<div class="social-wide-button"><a target=_blank href="http://www.facebook.com/share.php?u=<?php the_permalink(); ?>" class="pure-button facebook-wide-button"><span class="socicon socicon-facebook"></span> Share on Facebook</a></div>
			<div class="social-wide-button"><a target=_blank href="https://plus.google.com/share?url=<?php the_permalink(); ?>
	" class="pure-button google-wide-button"><span class="socicon socicon-google"></span> Share on Google+</a></div>
			<div class="clear"></div>
		</div>
	
	<?php endif; ?>

</article><!-- #post-## -->
