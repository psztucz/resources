<?php

/** 
* Template Name: Contact Page Template
*/

get_header(); ?>	

<div class="grid_6 contact-map">
	<?php echo get_post_meta($post->ID, 'published_map_code', true); ?>
</div>

<div id="primary" class="grid_4 content-area">
	<main id="main" class="site-main" role="main">
		<?php while ( have_posts() ) : the_post(); ?>
			<?php get_template_part( 'content', 'page' ); ?>
		<?php endwhile; // end of the loop. ?>
	</main>
</div>

<div class="grid_2 contact-info">
	<?php echo get_post_meta($post->ID, 'published_contact', true); ?>
</div>

<?php get_footer(); ?>