<?php
/**
 * The Sidebar containing the Home Page Sidebar
 *
 * @package fotok
 * @since fotok 1.0
 */
?>

	<?php
		if (   ! is_active_sidebar( 'home-sidebar-1' ) )
			return;
	?>

	<div id="home-sidebar" class="clear">
		<?php if ( is_active_sidebar( 'home-sidebar-1' ) ) : ?>
			<div id="home-sidebar-1" class="widget-area" role="complementary">
				<?php dynamic_sidebar( 'home-sidebar-1' ); ?>
			</div><!-- .widget-area -->
		<?php endif; ?>
	</div><!-- #home-sidebar -->