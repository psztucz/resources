<?php


/**
 * Adds Social widget.
 */
class Social_Widget extends WP_Widget {
  /**
	 * Register widget with WordPress.
	 */
	public function __construct() {
		parent::__construct(
	 		'social_widget', // Base ID
			'Social Widget', // Name
			array( 'description' => __( 'A Social Widget', 'ot-published' ), ) // Args
		);
	}
	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		echo $before_widget;
		if ( ! empty( $title ) )
			echo $before_title . $title . $after_title;
			echo display_social_links();
			echo $after_widget;
	}
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = strip_tags( $new_instance['title'] );
		return $instance;
	}
	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		if ( isset( $instance[ 'title' ] ) ) {
			$title = $instance[ 'title' ];
		}
		else {
			$title = __( 'New title', 'ot-published' );
		}
		?>
		<p>
		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'ot-published' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<?php
	}
} // class Foo_Widget

// Register and load the widget

function published_load_widget() {

    register_widget( 'Social_Widget' );

}
add_action( 'widgets_init', 'published_load_widget' );


function display_social_links() {

  $twitter = ot_get_option('twitter_url');
  $facebook = ot_get_option('facebook_url');
  $google = ot_get_option('google_url');
  $pinterest = ot_get_option('pinterest_url');
  $linkedin = ot_get_option('linkedin_url');
  $youtube = ot_get_option('youtube_url');
  $instagram = ot_get_option('instagram_url');
  $rss = ot_get_option('rss_url');

  $social_links = '<ul class="social">';

  if ($twitter) { $social_links .= '<li><a class="social-icon twitter" target="_blank" href="'.esc_url($twitter).'"><span class="socicon socicon-twitter"></span></a></li>';}

  if ($facebook) { $social_links .= '<li><a class="social-icon facebook" target="_blank" href="'.esc_url($facebook).'"><span class="socicon socicon-facebook"></span></a></li>'; }

  if ($google) { $social_links .= '<li><a class="social-icon google" target="_blank" href="'.esc_url($google).'"><span class="socicon socicon-google"></span></a></li>'; }

  if ($linkedin) { $social_links .= '<li><a class="social-icon linkedin" target="_blank" href="'.esc_url($linkedin).'"><span class="socicon socicon-linkedin"></span></a></li>'; }

  if ($youtube) { $social_links .= '<li><a class="social-icon youtube" target="_blank" href="'.esc_url($youtube).'"><span class="socicon socicon-youtube"></span></a></li>'; }

  if ($instagram) { $social_links .= '<li><a class="social-icon instagram" target="_blank" href="' . esc_url($instagram) . '"><span class="socicon socicon-instagram"></span></a></li>'; }
  
  if ($rss) { $social_links .= '<li><a class="social-icon rss" target="_blank" href="'.esc_url($rss).'"><span class="socicon socicon-rss"></span></a></li>'; }			

  if ($pinterest) { $social_links .= '<li><a class="social-icon pinterest" target="_blank" href="'.esc_url($pinterest).'"><span class="socicon socicon-pinterest"></span></a></li>'; }				

  $social_links .= '</ul>';
  
  return $social_links;
  
} 