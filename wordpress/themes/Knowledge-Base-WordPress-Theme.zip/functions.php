<?php
/**
 * apollo functions and definitions
 *
 * @package apollo
 */

define( 'THEME_URL', 'http://olympusthemes.com');

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 640; /* pixels */
}

if ( ! function_exists( 'ot_apollo_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function ot_apollo_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on apollo, use a find and replace
	 * to change 'ot-apollo' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'ot-apollo', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'apollo-post-thumb', 710, 9999 ); 

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'ot-apollo' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption',
	) );

}
endif; // ot_apollo_setup

add_action( 'after_setup_theme', 'ot_apollo_setup' );

function ot_apollo_add_editor_styles() {
	add_editor_style( 'ot-editor-style.css' );
}
add_action( 'admin_init', 'ot_apollo_add_editor_styles' );

/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function apollo_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'ot-apollo' ),
		'id'            => 'sidebar-1',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h5 class="widget-title">',
		'after_title'   => '</h5>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Knowledge Sidebar', 'ot-apollo' ),
		'id'            => 'sidebar-2',
		'description'   => 'Sidebar shown on knowledge base pages.',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h5 class="widget-title">',
		'after_title'   => '</h5>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer One', 'ot-apollo' ),
		'id'            => 'footer-1',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h5 class="widget-title">',
		'after_title'   => '</h5>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer Two', 'ot-apollo' ),
		'id'            => 'footer-2',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h5 class="widget-title">',
		'after_title'   => '</h5>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer Three', 'ot-apollo' ),
		'id'            => 'footer-3',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h5 class="widget-title">',
		'after_title'   => '</h5>',
	) );
}
add_action( 'widgets_init', 'apollo_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function ot_apollo_scripts() {
	wp_enqueue_style( 'ot-base-style', get_stylesheet_uri() );
	wp_enqueue_style( 'ot-base-grid', get_template_directory_uri() . '/assets/css/grid.css' );
	wp_enqueue_style( 'ot-apollo-style', get_template_directory_uri() . '/assets/css/apollo.css' );
	wp_enqueue_style( 'ot-print-style', get_template_directory_uri() . '/assets/css/print.css', array(), '1.0.0', 'print'  );
	wp_enqueue_style( 'ot-apollo-fa', get_template_directory_uri() . '/assets/css/font-awesome.css' );
	wp_enqueue_style( 'ot-apollo-font', 'http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,600,700' );

	wp_enqueue_script( 'jquery' );	
	wp_enqueue_script( 'ot-navigation', get_template_directory_uri() . '/assets/js/tinynav.js', array(), '20120206', true );
	wp_enqueue_script( 'ot-apollo-js', get_template_directory_uri() . '/assets/js/apollo.js', array(), '20120206', true );

	wp_enqueue_script( 'ot-apollo-skip-link-focus-fix', get_template_directory_uri() . '/assets/js/skip-link-focus-fix.js', array(), '20130115', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'ot_apollo_scripts' );

/**
 * Implement the Custom Header feature.
 */
//require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/customizer-options.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/kirki/kirki.php';

require get_template_directory() . '/inc/custom-fonts.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/load-plugins.php';

/**
 * Load 'sections' widget
 */
require get_template_directory() . '/inc/widgets/section-widget.php';



/**
 * The configuration options for the Shoestrap Customizer
 */
function shoestrap_customizer_config() {

	$args = array(

		// If Kirki is embedded in your theme, then you can use this line to specify its location.
		// This will be used to properly enqueue the necessary stylesheets and scripts.
		// If you are using kirki as a plugin then please delete this line.
		'url_path'     => get_template_directory_uri() . '/inc/kirki/',

		// If you want to take advantage of the backround control's 'output',
		// then you'll have to specify the ID of your stylesheet here.
		// The "ID" of your stylesheet is its "handle" on the wp_enqueue_style() function.
		// http://codex.wordpress.org/Function_Reference/wp_enqueue_style
		'stylesheet_id' => 'shoestrap',

	);

	return $args;

}
add_filter( 'kirki/config', 'shoestrap_customizer_config' );




/* Display a notice that can be dismissed */

add_action('admin_notices', 'docs_admin_notice');

function docs_admin_notice() {
	global $current_user ;
        $user_id = $current_user->ID;
        /* Check that the user hasn't already clicked to ignore the message */
	if ( ! get_user_meta($user_id, 'docs_ignore_notice') ) {
        echo '<div class="updated"><p>'; 
        printf(__('Have you seen the <a href="http://olympusthemes.com/ApolloThemeDocumentation.pdf">Apollo Theme Documentation</a>? | <a href="%1$s">Hide Notice</a>'), '?docs_nag_ignore=0');
        echo "</p></div>";
	}
}

add_action('admin_init', 'docs_nag_ignore');

function docs_nag_ignore() {
	global $current_user;
        $user_id = $current_user->ID;
        /* If user clicks to ignore the notice, add that to their user meta */
        if ( isset($_GET['docs_nag_ignore']) && '0' == $_GET['docs_nag_ignore'] ) {
             add_user_meta($user_id, 'docs_ignore_notice', 'true', true);
	}
}

require_once('inc/wp-updates-theme.php');
new WPUpdatesThemeUpdater_1227( 'http://wp-updates.com/api/2/theme', basename( get_template_directory() ) );