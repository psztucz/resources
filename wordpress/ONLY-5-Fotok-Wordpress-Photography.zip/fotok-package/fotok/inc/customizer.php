<?php
/**
 * fotok Theme Customizer
 *
 * @package fotok
 * @since fotok 1.0
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function fotok_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
}
add_action( 'customize_register', 'fotok_customize_register' );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function fotok_customize_preview_js() {
	wp_enqueue_script( 'fotok_customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20130508', true );
}
add_action( 'customize_preview_init', 'fotok_customize_preview_js' );

/**
 * Customizer
 *
 * @since fotok 1.0
 */
function fotok_theme_customizer( $wp_customize ) {

	/*--------------------------------------------------------------
		Layout
	--------------------------------------------------------------*/
	$wp_customize->add_section( 'fotok_layout_section' , array(
	    'title'       => __( 'Layout', 'fotok' ),
	    'priority'    => 20,
	    'description' => 'Custom Site Left and Single Post',
	) );

	$wp_customize->add_setting('fotok_siteleft', array(
        'default'        => 'fixed',
    ) );

	$wp_customize->add_control(
	    'fotok_siteleft',
	    array(
	        'label' => 'Site Left',
	        'section' => 'fotok_layout_section',
	        'type' => 'select',
			'choices' => array(
				'fixed' => 'Fixed',
				'relative' => 'Not Fixed'
			),
	));

	/*--------------------------------------------------------------
		Author Bio
	--------------------------------------------------------------*/
	$wp_customize->add_setting('fotok_author', array(
        'default'        => 'inherit',
    ) );

	$wp_customize->add_control(
	    'fotok_author',
	    array(
	        'label' => 'Author Bio',
	        'section' => 'fotok_layout_section',
	        'type' => 'select',
			'choices' => array(
				'inherit' => 'Displayed',
				'none' => 'Not Displayed'
			),
	));

	/*--------------------------------------------------------------
		Share
	--------------------------------------------------------------*/
	$wp_customize->add_setting('fotok_share', array(
        'default'        => 'inherit',
    ) );

	$wp_customize->add_control(
	    'fotok_share',
	    array(
	        'label' => 'Social Share',
	        'section' => 'fotok_layout_section',
	        'type' => 'select',
			'choices' => array(
				'inherit' => 'Displayed',
				'none' => 'Not Displayed'
			),
	));
	
	/*--------------------------------------------------------------
		Logo
	--------------------------------------------------------------*/
	$wp_customize->add_section( 'fotok_logo_section' , array(
	    'title'       => __( 'Logo', 'fotok' ),
	    'priority'    => 30,
	    'description' => 'Upload a logo',
	) );

	$wp_customize->add_setting( 'fotok_logo' );

	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'fotok_logo', array(
    'label'    => __( 'Logo', 'fotok' ),
    'section'  => 'fotok_logo_section',
    'settings' => 'fotok_logo',
	) ) );

	/*--------------------------------------------------------------
		Colors
	--------------------------------------------------------------*/
	/* Body Font Color */
    $wp_customize->add_setting( 'fotok_body_color', array(
        'default'        => '#404040',
    ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fotok_body_color', array(
		'label'        => __( 'Body Font Color', 'fotok' ),
		'section'    => 'colors',
		'settings'   => 'fotok_body_color',
	) ) );

	/* Link Color */
    $wp_customize->add_setting( 'fotok_link_color', array(
        'default'        => '#404040',
    ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fotok_link_color', array(
		'label'        => __( 'Link Color', 'fotok' ),
		'section'    => 'colors',
		'settings'   => 'fotok_link_color',
	) ) );

	/* Link Hover Color */
    $wp_customize->add_setting( 'fotok_hover_color', array(
        'default'        => '#cccccc',
    ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fotok_hover_color', array(
		'label'        => __( 'Link Hover Color', 'fotok' ),
		'section'    => 'colors',
		'settings'   => 'fotok_hover_color',
	) ) );

	/*--------------------------------------------------------------
		Google Fonts and Font Size
	--------------------------------------------------------------*/
	$wp_customize->add_section( 'fotok_fonts_section' , array(
		'title'       => __( 'Fonts', 'fotok' ),
		'priority'    => 40,
		'description' => __( 'Choose Google Fonts and Font Size', 'fotok' ),
	) );

	/* Body Font */
	$wp_customize->add_setting( 'fotok_body_font', array(
		'default' => 'Lato',
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field',
	));
	
	$wp_customize->add_control( 'body_font_select_box', array(
		'settings' => 'fotok_body_font',
		'label' => __( 'Body Font:', 'fotok' ),
		'section' => 'fotok_fonts_section',
		'type' => 'select',
		'choices' => array(
			'Lato' => 'Lato (Default)',
			'Droid Sans Mono' => 'Droid Sans Mono',
			'Josefin Sans' => 'Josefin Sans',
			'Open Sans' => 'Open Sans',
			'Open Sans Condensed' => 'Open Sans Condensed',
			'Roboto Condensed' => 'Roboto Condensed',
			'Fjalla One' => 'Fjalla One',
		),
	));

	/* Body Font Size */
	$wp_customize->add_setting( 'fotok_body_font_size', array(
		'default' => '14px',
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field',
	));
	
	$wp_customize->add_control( 'body_font_size_select_box', array(
		'settings' => 'fotok_body_font_size',
		'label' => __( 'Body Font Size:', 'fotok' ),
		'section' => 'fotok_fonts_section',
		'type' => 'select',
		'choices' => array(
			'14px' => '14px (Default)',
			'15px' => '15px',
			'16px' => '16px',
			'17px' => '17px',
			'18px' => '18px',
			'19px' => '19px',
			'20px' => '20px',
		),
	));

	/* Headings Font */
	$wp_customize->add_setting( 'fotok_headings_font', array(
		'default' => 'Fjalla One',
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field',
	));
	
	$wp_customize->add_control( 'headings_font_select_box', array(
		'settings' => 'fotok_headings_font',
		'label' => __( 'Headings Font:', 'fotok' ),
		'section' => 'fotok_fonts_section',
		'type' => 'select',
		'choices' => array(
			'Fjalla One' => 'Fjalla One (Default)',
			'Droid Sans Mono' => 'Droid Sans Mono',
			'Josefin Sans' => 'Josefin Sans',
			'Open Sans' => 'Open Sans',
			'Open Sans Condensed' => 'Open Sans Condensed',
			'Roboto Condensed' => 'Roboto Condensed',
			'Lato' => 'Lato',
		),
	));

	/* Site Title Font Size */
	$wp_customize->add_setting( 'fotok_site_title_font_size', array(
		'default' => '36px',
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field',
	));
	
	$wp_customize->add_control( 'site_title_font_size_select_box', array(
		'settings' => 'fotok_site_title_font_size',
		'label' => __( 'Site Title Font Size:', 'fotok' ),
		'section' => 'fotok_fonts_section',
		'type' => 'select',
		'choices' => array(
			'36px' => '36px (Default)',
			'34px' => '34px',
			'32px' => '32px',
			'30px' => '30px',
			'28px' => '28px',
			'26px' => '26px',
			'24px' => '24px',
		),
	));

	/* Site Tagline Font Size */
	$wp_customize->add_setting( 'fotok_site_tagline_font_size', array(
		'default' => '14px',
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field',
	));
	
	$wp_customize->add_control( 'site_tagline_font_size_select_box', array(
		'settings' => 'fotok_site_tagline_font_size',
		'label' => __( 'Site Tagline Font Size:', 'fotok' ),
		'section' => 'fotok_fonts_section',
		'type' => 'select',
		'choices' => array(
			'14px' => '14px (Default)',
			'10px' => '10px',
			'12px' => '12px',
			'16px' => '16px',
			'18px' => '18px',
			'20px' => '20px',
			'22px' => '22px',
		),
	));

	/* Menu Font Size */
	$wp_customize->add_setting( 'fotok_menu_font_size', array(
		'default' => '14px',
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field',
	));
	
	$wp_customize->add_control( 'menu_font_size_select_box', array(
		'settings' => 'fotok_menu_font_size',
		'label' => __( 'Menu Font Size:', 'fotok' ),
		'section' => 'fotok_fonts_section',
		'type' => 'select',
		'choices' => array(
			'14px' => '14px (Default)',
			'10px' => '10px',
			'12px' => '12px',
			'16px' => '16px',
			'18px' => '18px',
			'20px' => '20px',
			'22px' => '22px',
		),
	));

	/* Entry Title Font Size */
	$wp_customize->add_setting( 'fotok_entry_title_font_size', array(
		'default' => '24px',
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field',
	));
	
	$wp_customize->add_control( 'entry_title_font_size_select_box', array(
		'settings' => 'fotok_entry_title_font_size',
		'label' => __( 'Blog Title Font Size:', 'fotok' ),
		'section' => 'fotok_fonts_section',
		'type' => 'select',
		'choices' => array(
			'24px' => '24px (Default)',
			'18px' => '18px',
			'20px' => '20px',
			'22px' => '22px',
			'26px' => '26px',
			'28px' => '28px',
			'30px' => '30px',
		),
	));

	/*--------------------------------------------------------------
		Footer Credits
	--------------------------------------------------------------*/
	$wp_customize->add_section( 'fotok_footer_section' , array(
	    'title'       => __( 'Footer Credits', 'fotok' ),
	    'priority'    => 80,
	    'description' => 'Custom Footer Credits',
	) );

	$wp_customize->add_setting('fotok_footer');

	$wp_customize->add_control(
	    'fotok_footer',
	    array(
	        'label' => 'Footer Credits',
	        'section' => 'fotok_footer_section',
	        'type' => 'text',
	    )
	);

	/*--------------------------------------------------------------
		Custom CSS
	--------------------------------------------------------------*/
	class Fotok_Customize_Textarea_Control extends WP_Customize_Control {
	    public $type = 'textarea';
	 
	    public function render_content() {
	        ?>
	            <label>
	                <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
	                <textarea rows="5" style="width:100%;" <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea>
	            </label>
	        <?php
	    }
	}

	$wp_customize->add_section( 'fotok_css_section' , array(
	    'title'       => __( 'Custom CSS', 'fotok' ),
	    'priority'    => 90,
	    'description' => 'You can add your custom CSS',
	) );

	$wp_customize->add_setting( 'fotok_css' );
	 
	$wp_customize->add_control(
	    new Fotok_Customize_Textarea_Control(
	        $wp_customize,
	        'fotok_css',
	        array(
	            'label' => 'Custom CSS',
	            'section' => 'fotok_css_section',
	            'settings' => 'fotok_css'
	        )
	    )
	);

	/*--------------------------------------------------------------
		Footer Scripts
	--------------------------------------------------------------*/
	$wp_customize->add_section( 'fotok_scripts_section' , array(
	    'title'       => __( 'Custom Footer Scripts', 'fotok' ),
	    'priority'    => 100,
	    'description' => 'You can add your custom Scripts in the footer without the tag "script". For example: google analytics.',
	) );

	$wp_customize->add_setting( 'fotok_scripts' );
	 
	$wp_customize->add_control(
	    new Fotok_Customize_Textarea_Control(
	        $wp_customize,
	        'fotok_scripts',
	        array(
	            'label' => 'Custom Scripts',
	            'section' => 'fotok_scripts_section',
	            'settings' => 'fotok_scripts'
	        )
	    )
	);
}
add_action('customize_register', 'fotok_theme_customizer');

/**
 * Customizer Apply Style
 *
 * @since fotok 1.0
 */
if ( ! function_exists( 'fotok_apply_style' ) ) :
  	
  	function fotok_apply_style() {	
		if ( get_theme_mod('fotok_body_color') || 
			 get_theme_mod('fotok_body_font') || 
			 get_theme_mod('fotok_body_font_size') || 
			 get_theme_mod('fotok_headings_font') || 
			 get_theme_mod('fotok_site_title_font_size') || 
			 get_theme_mod('fotok_site_tagline_font_size') || 
			 get_theme_mod('fotok_menu_font_size') || 
			 get_theme_mod('fotok_entry_title_font_size') || 
			 get_theme_mod('fotok_link_color') || 
			 get_theme_mod('fotok_hover_color') || 
			 get_theme_mod('fotok_siteleft') || 
			 get_theme_mod('fotok_author') || 
			 get_theme_mod('fotok_share') || 
			 get_theme_mod('fotok_css')
		) { 
		?>
			<style id="fotok-style-settings">
				<?php if ( get_theme_mod('fotok_body_color') || get_theme_mod('fotok_body_font') || get_theme_mod('fotok_body_font_size') ) : ?>
					body,
					button,
					input,
					select,
					textarea {
						color: <?php echo get_theme_mod('fotok_body_color');  ?>;
						font-family: "<?php echo get_theme_mod('fotok_body_font');  ?>", sans-serif;
						font-size: <?php echo get_theme_mod('fotok_body_font_size');  ?>;
					}
				<?php endif; ?>

				<?php if ( get_theme_mod('fotok_headings_font') ) : ?>
					h1, h2, h3, h4, h5, h6 {
						font-family: "<?php echo get_theme_mod('fotok_headings_font');  ?>", sans-serif;
					}
				<?php endif; ?>

				<?php if ( get_theme_mod('fotok_site_title_font_size') || get_theme_mod('fotok_site_tagline_font_size') ) : ?>
					.site-title {
						font-size: <?php echo get_theme_mod('fotok_site_title_font_size');  ?>;
					}
					.site-description {
						font-size: <?php echo get_theme_mod('fotok_site_tagline_font_size');  ?>;
					}
				<?php endif; ?>

				<?php if ( get_theme_mod('fotok_menu_font_size') ) : ?>
					.main-navigation {
						font-size: <?php echo get_theme_mod('fotok_menu_font_size');  ?>;
					}
				<?php endif; ?>

				<?php if ( get_theme_mod('fotok_entry_title_font_size') ) : ?>
					.entry-title {
						font-size: <?php echo get_theme_mod('fotok_entry_title_font_size');  ?>;
					}
				<?php endif; ?>

				<?php if ( get_theme_mod('fotok_link_color') ) : ?>
					a,
					a:visited {
						color: <?php echo get_theme_mod('fotok_link_color');  ?>;
					}
				<?php endif; ?>
			
				<?php if ( get_theme_mod('fotok_hover_color') ) : ?>
					a:hover,
					a:focus,
					a:active {
						color: <?php echo get_theme_mod('fotok_hover_color');  ?>;
					}
					#portfolio-shortcode .masonry-wrap header  {
						background-color: <?php echo get_theme_mod('fotok_hover_color');  ?>;
					}
				<?php endif; ?>
			</style>
			<style id="fotok-layout-settings">
				<?php if ( get_theme_mod('fotok_siteleft') ) : ?>
					@media (min-width: 1024px) {
						#site-left {
							position: <?php echo get_theme_mod('fotok_siteleft');  ?>;
						}
					}
				<?php endif; ?>

				<?php if ( get_theme_mod('fotok_author') ) : ?>
					.author-bio {
						display: <?php echo get_theme_mod('fotok_author');  ?>;
					}
				<?php endif; ?>

				<?php if ( get_theme_mod('fotok_share') ) : ?>
					.single-box {
						display: <?php echo get_theme_mod('fotok_share');  ?>;
					}
				<?php endif; ?>
			</style>
			<style id="fotok-custom-css">
				<?php if ( get_theme_mod('fotok_css') ) : ?>
					<?php echo get_theme_mod('fotok_css');  ?>;
				<?php endif; ?>
			</style>
		<?php
    }
}
endif;
add_action( 'wp_head', 'fotok_apply_style' );

/**
 * Customizer Footer
 *
 * @since fotok 1.0
 */
if ( ! function_exists( 'fotok_apply_footer' ) ) :
  	
  	function fotok_apply_footer() {	
		if ( get_theme_mod('fotok_scripts') ) { 
		?>

		<script id="fotok-custom-scriptss">
			<?php if ( get_theme_mod('fotok_scripts') ) : ?>
				<?php echo get_theme_mod('fotok_scripts');  ?>;
			<?php endif; ?>
		</script>
		<?php
    }
}
endif;
add_action('wp_footer', 'fotok_apply_footer');