<?php
/**
 * The Template for displaying all single books.
 *
 * @package published
 */

get_header(); ?>

<div class="grid_2 single-book-image" >		
<?php if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.  
the_post_thumbnail('book-full');} ?>
</div>
	<div id="primary" class="grid_4 content-area">
		<main id="main" class="site-main" role="main">

		<?php while ( have_posts() ) : the_post(); ?>
	
			<article id="post-<?php the_ID(); ?>" 
			<?php post_class(); ?>>	
			<header class="entry-header">		
			<h1 class="entry-title"><?php the_title(); ?></h1>	
			</header><!-- .entry-header -->
			<?php display_buy_links($post) ?>	
			<div class="entry-content">		
			<?php the_content(); ?>		
			<?php			wp_link_pages( array(				'before' => '<div class="page-links">' . __( 'Pages:', 'published' ),				'after'  => '</div>',			) );		?>	
			</div><!-- .entry-content -->
			</article><!-- #post-## -->

			<?php
				// If comments are open or we have at least one comment, load up the comment template
				if ( comments_open() || '0' != get_comments_number() ) :
					comments_template();
				endif;
			?>

		<?php endwhile; // end of the loop. ?>

		</main><!-- #main -->
	</div><!-- #primary -->
	
<?php get_footer(); ?>