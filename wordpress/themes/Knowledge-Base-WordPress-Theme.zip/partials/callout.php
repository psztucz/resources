<?php

$callout_text = get_theme_mod('callout_text');
$callout_button_text = get_theme_mod('callout_button_text');
$callout_button_url = get_theme_mod('callout_button_url');

?>


<div class="callout">
	<div class="grid">
		<div class="col-10-12">
			<?php if( $callout_text ) : ?>
				<p class="callout-text"><?php echo esc_html($callout_text); ?></p>
			<?php endif; ?>
		</div>
		<div class="col-2-12">
			<?php if( $callout_button_text && $callout_button_url ) : ?>
				<a class="callout-button" href="<?php echo esc_url($callout_button_url); ?>"><?php echo esc_html($callout_button_text); ?></a>
			<?php endif; ?>
		</div>
	</div>
</div>