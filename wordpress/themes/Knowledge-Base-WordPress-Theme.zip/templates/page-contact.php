<?php
/**
* Template Name: Contact Template
*/

$map_url = get_theme_mod('map_url');

get_header(); ?>

	<div id="primary" class="content-area col-8-12">
		
		<main id="main" class="site-main" role="main">

			<?php if ( $map_url = get_theme_mod('map_url') ) : ?>
				<div class="google-map">
					<iframe src="<?php echo esc_url($map_url); ?>" width="710" height="400" frameborder="0" style="border:0"></iframe>
				</div>
			<?php endif; ?>			
			
			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', 'page' ); ?>

				<?php
					// If comments are open or we have at least one comment, load up the comment template
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;
				?>

			<?php endwhile; // end of the loop. ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>