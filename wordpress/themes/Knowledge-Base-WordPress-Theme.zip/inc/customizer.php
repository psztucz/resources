<?php
/**
 * _s Theme Customizer
 *
 * @package _s
 */
/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function _s_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
}
add_action( 'customize_register', '_s_customize_register' );
/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function _s_customize_preview_js() {
	wp_enqueue_script( '_s_customizer', get_template_directory_uri() . '/assets/js/customizer.js', array( 'customize-preview' ), '20130508', true );
}
add_action( 'customize_preview_init', '_s_customize_preview_js' );

$apollo_customizations = array(
	
	'header_bg' => '.site-header',
	'header_bg' => '.site-description',
	
	
);

function apollo_header_output() {

  ?>
  <!--Customizer CSS--> 
  <style type="text/css">
    <?php apollo_generate_css('.site-header', 'background', 'header_bg'); ?>        
    <?php apollo_generate_css('.site-title a, .site-description', 'color', 'logo_color'); ?>        
    <?php apollo_generate_css('.main-navigation a', 'color', 'nav_color'); ?>        
    <?php apollo_generate_css('.highlight', 'border-color', 'nav_color'); ?>        
    <?php apollo_generate_css('.hero', 'background', 'hero_bg'); ?>        
    <?php apollo_generate_css('.video-background', 'background-image', 'hero_image', 'url("', '")' ); ?>        
    <?php apollo_generate_css('.callout', 'background', 'callout_bg'); ?>        
    <?php apollo_generate_css('.footer', 'background', 'footer_bg'); ?>        
    <?php apollo_generate_css('.sub_footer', 'background', 'sub_footer_bg'); ?>        
    <?php apollo_generate_css('.site-main a', 'color', 'link_color'); ?>        
    <?php apollo_generate_css('#page .apollo-button, .comments-area .submit, .nav-links a, .page-numbers .current, .wpcf7-submit', 'color', 'button_color'); ?>        
    <?php apollo_generate_css('#page .apollo-button, .comments-area .submit, .nav-links a, .page-numbers .current, .wpcf7-submit', 'background', 'button_bg'); ?>        
    <?php apollo_generate_css('.archive-header', 'border-color', 'button_bg'); ?>        
    <?php apollo_generate_css('body', 'font-family', 'primary_font'); ?>        
    <?php apollo_generate_css('h1, h2, h3, h4, h5, h6', 'font-family', 'secondary_font'); ?>      
	<?php echo get_theme_mod('custom_css'); ?>
</style> 
  <!--/Customizer CSS-->
  <?php
}

// Output custom CSS to live site
add_action( 'wp_head' , 'apollo_header_output' );

function apollo_generate_css( $selector, $style, $option_name, $prefix='', $postfix='', $echo=true ) {
  $return = '';
  $mod = get_theme_mod($option_name);
  if ( ! empty( $mod ) ) {
     $return = sprintf('%s { %s:%s; }',
        $selector,
        $style,
        $prefix.$mod.$postfix
     );
     if ( $echo ) {
        echo $return;
     }
  }
  return $return;
}