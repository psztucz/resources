jQuery(document).ready(function() {
  jQuery(function() {
    jQuery(".menu").tinyNav();
  });
  jQuery('.back-to-top').click(function(event) {
    event.preventDefault();
    jQuery('html, body').animate({
      scrollTop: 0
    }, 2000);
    return false;
  });

  jQuery("pre.html").snippet("html", {
    style: "pablo"
  });
  jQuery("pre.css").snippet("css", {
    style: "pablo"
  });
  jQuery("pre.js").snippet("javascript", {
    style: "pablo"
  });
  if (jQuery('.isotope').length) {

    var jQuerycontainer = jQuery('.isotope').imagesLoaded(function() {
      jQuerycontainer.isotope({
        itemSelector: '.mason',
        masonry: {
          columnWidth: 340
        }
      });
    });
  };
}); 