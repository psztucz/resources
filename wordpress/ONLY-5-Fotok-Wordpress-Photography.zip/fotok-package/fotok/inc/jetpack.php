<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package fotok
 * @since fotok 1.0
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function fotok_jetpack_setup() {
	add_theme_support( 'infinite-scroll', array(
		'container' => 'main',
		'footer'    => 'page',
	) );
}
add_action( 'after_setup_theme', 'fotok_jetpack_setup' );
