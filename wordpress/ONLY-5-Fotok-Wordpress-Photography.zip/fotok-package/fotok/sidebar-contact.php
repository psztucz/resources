<?php
/**
 * The Sidebar containing the Contact Sidebar
 *
 * @package fotok
 * @since fotok 1.0
 */
?>

	<?php
		if (   ! is_active_sidebar( 'contact-sidebar-1' ) )
			return;
	?>

	<div id="contact-sidebar" class="clear">
		<?php if ( is_active_sidebar( 'contact-sidebar-1' ) ) : ?>
			<div id="contact-sidebar-1" class="widget-area" role="complementary">
				<?php dynamic_sidebar( 'contact-sidebar-1' ); ?>
			</div><!-- .widget-area -->
		<?php endif; ?>
	</div><!-- #contact-sidebar -->