<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url() ); ?>">
	<label>
		<span class="screen-reader-text">Search the knowledge base</span>
		<input type="search" class="search-field" placeholder="Search the knowledge base..." value="" name="s" title="Search for:">
	</label>
	         <input type="image" class="search-submit apollo-button" alt="Search" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/search-icon.png" />

</form>