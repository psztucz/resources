<?php

/**
 * Initialize the custom Meta Boxes. 
 */
add_action( 'admin_init', 'published_meta_boxes' );

/**
 * Meta Boxes demo code.
 *
 * You can find all the available option types in demo-theme-options.php. 
 *
 * @return    void
 * @since     2.0
 */
function published_meta_boxes() {
  
  $retailers = get_retailers();
	
  /**
   * Create a custom meta boxes array that we pass to 
   * the OptionTree Meta Box API Class.
   */
  $post_image_slider = array(
    'id'          => 'contact_meta_box',
    'title'       => __( 'Contact Form Settings', 'ot-published' ),
    'desc'        => __( 'These settings can only be used when the contact template is active.', 'ot-published' ),
    'pages'       => array( 'page' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(

	     array(
        'label'       => __( 'Google Maps Code', 'ot-published' ),
        'id'          => 'published_map_code',
        'desc'        => __( 'Place your map embed here.', 'ot-published' ),
		'std'         => '',
        'type'        => 'textarea-simple',
        'class'       => '',
      ),
	  
	  	array(
        'label'       => __( 'Address and Contact Info', 'ot-published' ),
        'id'          => 'published_contact',
        'desc'        => __( 'Place your contact information here.', 'ot-published' ),
		'std'         => '',
        'type'        => 'textarea',
        'class'       => '',
      ),
	
    )
  );
  
   $formats_meta_box = array(
    'id'          => 'formats_meta_box',
    'title'       => __( 'Video & Audio Settings', 'ot-published' ),
    'desc'        => __( 'Remember to select the post format you would like to use from the list on the right.', 'ot-published' ),
    'pages'       => array( 'post' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(



      array(
        'label'       => __( 'Video/Audio Code', 'ot-published' ),
        'id'          => 'published_video_code',
        'desc'        => __( 'Place your video or audio embed code here.', 'ot-published' ),
		'std'         => '',
        'type'        => 'textarea',
        'class'       => '',
      )
    )
  );
  
   $books_meta_box = array(
    'id'          => 'url_meta_box',
    'title'       => __( 'Purchase URLs', 'ot-published' ),
    'desc'        => __( 'Enter the URLs where your book can be purchased below.', 'ot-published' ),
    'pages'       => array( 'book' ),
    'context'     => 'normal',
    'priority'    => 'low',
    'fields'      => array(


    )
  );
  

	foreach($retailers as $id => $name) {

		$books_meta_box['fields'][] = array(
					'label'       => $name.' URL',
					'id'          => 'published_'.$id.'_url',
					'desc'        => 'Place your '.$name.' link here.',
					'std'         => '',
					'type'        => 'text',
					'class'       => '',
		);

	}		
			
	
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  if ( function_exists( 'ot_register_meta_box' ) )
    ot_register_meta_box( $post_image_slider );
    ot_register_meta_box( $formats_meta_box );
    ot_register_meta_box( $books_meta_box );

}