Plugins are installed automaticlly when you install the Theme. If you need them later on, you can find them in this
directory. A short description is below.

Theme uses 4 plugins for full functionality, below is a short description with links for all of them:

1. page-builder-pmc
   - this is our plugin which adds shortcodes and page builder for the Theme (this is a must have)

2. revslider
   - this plugin adds the Revolution Slider, it's a premium plugin from Codecanyon and is a plugin we will
     update when there are newer versions

3. contact-form-7.3.5.3 - CONTACT FORM
   - this is a plugin that you will need of you want to add the contact form. Plugin can be downloaded
     from Wordpress repository at: http://wordpress.org/plugins/contact-form-7/

4. twitter-widget-pro.2.6.0 - TWITTER PLUGIN
   - this is a plugin that you will need if you want to add the Twitter block (in our live demo the block
     just above the footer). Plugin can be downloaded from this website: http://ran.ge/wordpress-plugin/twitter-widget-pro/
