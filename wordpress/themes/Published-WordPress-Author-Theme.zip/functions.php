<?php
/**
 * base functions and definitions
 *
 * @package base
 */
if ( ! isset( $content_width ) ) {	$content_width = 610;}

if ( ! function_exists( 'base_setup' ) ) :

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function base_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 */
	load_theme_textdomain( 'published', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	add_theme_support( 'post-thumbnails' );

	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'base' ),
	) );

	// Enable support for HTML5 markup.
	add_theme_support( 'html5', array(
		'comment-list',
		'search-form',
		'comment-form',
		'gallery',
	) );
	
	add_image_size( 'homepage-thumb', 150, 150, true );
	add_image_size( 'single-feature', 690); 
	add_image_size( 'book-thumb', 150); 
	add_image_size( 'book-thumb', 300); 
	add_image_size( 'book-full', 500); 
}
endif; 

add_action( 'after_setup_theme', 'base_setup' );

/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function base_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'base' ),
		'id'            => 'sidebar-1',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Left', 'base' ),
		'id'            => 'footer-left',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Middle', 'base' ),
		'id'            => 'footer-middle',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Right', 'base' ),
		'id'            => 'footer-right',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'base_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function base_scripts() {
	wp_enqueue_style( 'base-style', get_stylesheet_uri() );
	wp_enqueue_style( 'base-design', get_template_directory_uri() . '/css/published.css' );
	wp_enqueue_style( 'base-fonts', 'http://fonts.googleapis.com/css?family=Lato:400,700,900,400italic|Bitter:400,900,700,400italic' );
	wp_enqueue_style( 'base-icons', get_template_directory_uri() . '/css/font-awesome.min.css'  );
	wp_enqueue_style( 'base-responsive', get_template_directory_uri() . '/css/responsive.css' );
	wp_enqueue_script( 'jquery' );	
	wp_enqueue_script( 'base-code', get_template_directory_uri() . '/js/jquery.snippet.min.js' );
	wp_enqueue_script( 'base-tinynav', get_template_directory_uri() . '/js/tinynav.min.js' );
	wp_enqueue_script( 'base-custom', get_template_directory_uri() . '/js/custom.js' );
	wp_enqueue_script( 'base-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	
	if ( is_page_template('blog-grid.php') ) {
			wp_enqueue_script( 'base-mason', get_template_directory_uri() . '/js/isotope.pkgd.min.js' );
			wp_enqueue_script( 'base-loaded', get_template_directory_uri() . '/js/imagesloaded.pkgd.min.js' );
	}
	
}
add_action( 'wp_enqueue_scripts', 'base_scripts' );


require get_template_directory() . '/inc/css.php';
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/extras.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/jetpack.php';
require get_template_directory() . '/inc/shortcodes.php';

function excerpt_read_more_link($output) {

	global $post;
	return $output . '<p class="read-more"><a href="'. get_permalink($post->ID) . '">'.__('Continue reading', 'published').' &rarr;</a></p>';

}

add_filter('the_excerpt', 'excerpt_read_more_link');


function published_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case 'pingback' :
		case 'trackback' :
		// Display trackbacks differently than normal comments.
	?>
	<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
		<p><?php _e( 'Pingback:', 'published' ); ?> <?php comment_author_link(); ?> <?php edit_comment_link( __( '(Edit)', 'published' ), '<span class="edit-link">', '</span>' ); ?></p>
	<?php
			break;
		default :
		// Proceed with normal comments.
		global $post;
	?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<article id="comment-<?php comment_ID(); ?>" class="comment">
			<header class="comment-meta comment-author vcard">
				<?php
					echo get_avatar( $comment, 44 );
					printf( '<cite><b class="fn">%1$s</b> %2$s</cite>',
						get_comment_author_link(),
						// If current post author is also comment author, make it known visually.
						( $comment->user_id === $post->post_author ) ? '<span>' . __( 'Post author', 'published' ) . '</span>' : ''
					);
					printf( '<a href="%1$s"><time datetime="%2$s">%3$s</time></a>',
						esc_url( get_comment_link( $comment->comment_ID ) ),
						get_comment_time( 'c' ),
						/* translators: 1: date, 2: time */
						sprintf( __( '%1$s at %2$s', 'published' ), get_comment_date(), get_comment_time() )
					);
				?>
			</header><!-- .comment-meta -->

			<?php if ( '0' == $comment->comment_approved ) : ?>
				<p class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'published' ); ?></p>
			<?php endif; ?>

			<section class="comment-content comment">
				<?php comment_text(); ?>
				<?php edit_comment_link( __( 'Edit', 'published' ), '<p class="edit-link">', '</p>' ); ?>
			</section><!-- .comment-content -->

			<div class="reply">
				<?php comment_reply_link( array_merge( $args, array( 'reply_text' => __( 'Reply', 'published' ), 'after' => ' <span>&darr;</span>', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
			</div><!-- .reply -->
		</article><!-- #comment-## -->
	<?php
		break;
	endswitch; // end comment_type check
}


add_filter( 'ot_theme_mode', '__return_true' );

load_template( trailingslashit( get_template_directory() ) . 'option-tree/ot-loader.php' );
load_template( trailingslashit( get_template_directory() ) . 'option-tree/assets/theme-mode/demo-meta-boxes.php' );
load_template( trailingslashit( get_template_directory() ) . 'options.php' );

add_filter( 'ot_show_pages', '__return_false' );
add_filter( 'ot_show_new_layout', '__return_false' );
add_filter( 'ot_theme_options_contextual_help', '__return_true' );

function change_logo($content) {
	$content = '';
	return $content;
}
  
add_filter('ot_header_logo_link','change_logo');

function change_logo_text($content) {
	$content = 'Base Theme Options';	
  return $content;	
}

add_filter('ot_header_version_text', 'change_logo_text');

function change_button_text($content) {
	global $post;
	$content = 'Use this Image';
	return $content;
}

add_filter('ot_upload_text','change_button_text');

function filter_typography_fields( $array, $field_id ) {
	$array = array( 'font-family', 'font-size', 'font-weight', 'font-color');
	return $array;
}

add_filter( 'ot_recognized_typography_fields', 'filter_typography_fields', 10, 2 );


/**
 * Google Font Loading
 *
 * Returns an array of saved Google Fonts.
 * Updates Google Font database in interval given
 *
 *	@param  	string 	$key 		Google Font API key
 *	@param  	int		$key 		Google Font cache refresh interval in ms
 *
 * @return	array
 *
 */

if( !function_exists( 'ot_get_google_font' ) ) :

	function ot_get_google_font($interval = 604800 ){

		// get the themes name
		$_theme = wp_get_theme();
		$_theme_name = strtolower(str_replace(' ', '_', $_theme->name));

		// get cached fields
		$db_cache_field               = 'googlefont-cache-'.$_theme_name;
		$db_cache_field_last_updated  = 'googlefont-cache-last-'.$_theme_name;
		$db_cache_field_themename     = 'googlefont-'.$_theme_name;

		$current_fonts = get_option( $db_cache_field ); // get current fonts
		$last 			   = get_option( $db_cache_field_last_updated ); // get the date for last update
		$theme 			   = get_option ( $db_cache_field_themename ); // get the theme name
		$now 			     = time(); // get current timestamp


			if ( !$last || ( ($now - $last ) > $interval ) || !$theme || $current_fonts == "" || !$current_fonts ) {

				$fontsSeraliazed = 'http://olympusthemes.com/fonts.json';

        // get the Google Fonts from remote URL
        $google_response = wp_remote_get ( $fontsSeraliazed, array ( 'sslverify' => false ) );

        // we have no errors, proceed
        if ( 200 == wp_remote_retrieve_response_code( $google_response ) ) {

  				// parse the result from Google Font   
  				$fontArray = json_decode($google_response['body'], true);

  				$googleFontArray = array();

  				// generate the array to store the fonts
  				foreach($fontArray['items'] as $index => $value){
  					$_family                               = strtolower( str_replace(' ','_',$value['family']) );
  					$googleFontArray[$_family]['family']   = $value['family'];
  					$googleFontArray[$_family]['variants'] = $value['variants'];
  					$googleFontArray[$_family]['subsets']  = $value['subsets'];
  				}

  				if ( is_array($googleFontArray) ) {

  					// we got good results, so update the existing fields
  					update_option( $db_cache_field, $googleFontArray );
  					update_option( $db_cache_field_last_updated, time() );
  					update_option( $db_cache_field_themename, $_theme_name );

  				} else {

  					// there are no fields, so add them to the database
  					add_option( $db_cache_field, $googleFontArray,'', 'no' );
  					add_option( $db_cache_field_last_updated, time(),'', 'no' );
  					add_option( $db_cache_field_themename, $_theme_name,'', 'no' );

  				}

  				// get the google font array from options DB
  				$db_font_array = get_option( $db_cache_field );

				
          // we are using the already stored fonts
  				if( is_array($current_fonts) && count($current_fonts) ) {
  					$db_font_array = $current_fonts;
  				}

        }

			} else {

				// get the google font array from options DB
				if( is_array($current_fonts) && count($current_fonts) ) {
					$db_font_array = $current_fonts;
				}

			}

			return $db_font_array;

	}

	add_action( 'wp_enqueue_scripts', 'ot_get_google_font', 999 );

endif;


/**
 * Google Fonts Ajax Callback
 *
 * Returns a json string with all Google Fonts from DB
 *
 * @return string
 *
 */
	function ot_ajax_get_google_font(){

			// get the current themes name
			$_theme = wp_get_theme();
			$_theme_name = strtolower(str_replace(' ', '_', $_theme->name));

			$fonts = get_option('googlefont-cache-'.$_theme_name);

			die(json_encode($fonts));

	}
	// creating Ajax call for WordPress
	add_action( 'wp_ajax_nopriv_ot_ajax_get_google_font', 'ot_ajax_get_google_font' );
	add_action( 'wp_ajax_ot_ajax_get_google_font', 'ot_ajax_get_google_font' );


/**
 * Get Google Font stylesheets
 *
 * Includes the Google Font stylesheets into the head section of the current page
 *
 * @param	array		$default_theme_fonts the default theme fonts set before
 *
 * @uses		wp_enqueue_style(), wp_enqueue_script()
 *
 */
	function ot_action_get_google_font_link(){

		if (!is_admin()) {

  		// get the themes name
  		$_theme = wp_get_theme();
  		$_theme_name = strtolower(str_replace(' ', '_', $_theme->name));

		  $_def_fonts = unserialize(OT_FONT_DEFAULTS);

			// lets get all the font options from the option tree settings
			$_ot_options = get_option( 'option_tree_settings' );

			$_font_array = array();
			foreach($_ot_options['settings'] as $index => $_setting){
				if($_setting['type'] == 'typography'){
					$_font_array[] = ot_get_option($_setting['id']);
				}
			}

			// array to store already used font-families and not load them double
			$_font_array_backup = array();

			// loop through fonts
			foreach( $_font_array as $index => $font ){

				$_output = "";

				if( !empty($font) && is_array($font) ) :

					// get the google font array from db cache
					$_db_font_cache = get_option( 'googlefont-cache-'.$_theme_name );

					if($_def_fonts):

            if( isset($_db_font_cache[$font['font-family']]['family']) ) {

					  	if( !array_key_exists($font['font-family'], $_def_fonts) ) {
						    $_output = $_db_font_cache[$font['font-family']]['family'];
              }

						}

					endif;

					// check if the font family allready exists
					if( array_key_exists($font['font-family'], $_db_font_cache) ) {
						$_font_array_backup[$font['font-family']] = $_db_font_cache[$font['font-family']];
					}

				endif;
			}

			// loop through the font array and enqueue the google font stylesheet if needed
			if( is_array($_font_array_backup) && !empty($_font_array_backup) ){

				foreach($_font_array_backup as $index => $_g_font_family){

				  if(!empty($_g_font_family)){

				     // build the font weight string
				     $_font_weight_array = array();
				     foreach($_font_array as $font => $value) {

               // check if font-weight exists for this font-family
  				     if(!empty($value['font-weight']) && $value['font-family'] == $index ) :

                  // check if font-weight already exists, if not, add it to the array
                  if(!in_array($value['font-weight'], $_font_weight_array)):

                    // replace font-weight keywords
                    if($value['font-weight'] == 'normal') $value['font-weight'] = 400;
                    if($value['font-weight'] == 'bold') $value['font-weight'] = 500;

                    $_font_weight_array[] = $value['font-weight'];

                  endif;

  				     endif;

				     }

             $_font_add_string = "";
             if(count($_g_font_family['variants'])) $_font_add_string .= ":". implode(',', $_g_font_family['variants']);

				     // build the font style string
				     $_font_style_array = array();
				     foreach($_font_array as $font => $value) {

               // check if font-style exists for this font-family
  				     if(!empty($value['font-style']) && $value['font-family'] == $index ) :

                  // check if font-style already exists, if not, add it to the array
                  if(!in_array($value['font-style'], $_font_style_array)):
                    $_font_style_array[] = $value['font-style'];
                  endif;

  				     endif;

				     }

             // check, if we already have some font-weights
             if(count($_font_style_array)) {
               if(empty($_font_add_string)) {
                  $_font_add_string .= ":". implode(',', $_font_style_array);
               }else{
                  $_font_add_string .= ",". implode(',', $_font_style_array);
               }
             }

					   wp_register_style( 'ot-google-font-' . $index, 'http://fonts.googleapis.com/css?family=' . $_g_font_family['family'] . $_font_add_string, array(), '', 'all');
					   wp_enqueue_style( 'ot-google-font-' . $index );
					}
				}
			}

		}

	}

	// Action to call the google font include on frontpage
	add_action('wp_enqueue_scripts', 'ot_action_get_google_font_link', 15);
	
	/* =============================================================================
	Include the Option-Tree Google Fonts Plugin
	========================================================================== */

	// load the ot-google-fonts plugin if the loader class is available
	if( class_exists( 'OT_Loader' ) ):

	  global $ot_options;

	  $ot_options = get_option( 'option_tree' );

  	// default fonts used in this theme, even though there are no google fonts
  	$default_theme_fonts = array(
  			'arial' => 'Arial, Helvetica, sans-serif',
  			'helvetica' => 'Helvetica, Arial, sans-serif',
  			'georgia' => 'Georgia, "Times New Roman", Times, serif',
  			'tahoma' => 'Tahoma, Geneva, sans-serif',
  			'times' => '"Times New Roman", Times, serif',
  			'trebuchet' => '"Trebuchet MS", Arial, Helvetica, sans-serif',
  			'verdana' => 'Verdana, Geneva, sans-serif'
  	);

  	defined('OT_FONT_DEFAULTS') or define('OT_FONT_DEFAULTS', serialize($default_theme_fonts));
  	defined('OT_FONT_CACHE_INTERVAL') or define('OT_FONT_CACHE_INTERVAL', 0); // Checking once a week for new Fonts. The time interval for the remote XML cache in the database (21600 seconds = 6 hours)

		// get the OT-Google-Font plugin file

		// get the google font array - build in ot-google-fonts.php
		$google_font_array = ot_get_google_font(OT_FONT_CACHE_INTERVAL);

		// Now apply the fonts to the font dropdowns in theme options with the build in OptionTree hook
		function ot_filter_recognized_font_families( $array, $field_id ) {

			global $google_font_array;

			// loop through the cached google font array if available and append to default fonts
			$font_array = array();
			if($google_font_array){
					foreach($google_font_array as $index => $value){
							$font_array[$index] = $value['family'];
					}
			}

			// put both arrays together
			$array = array_merge(unserialize(OT_FONT_DEFAULTS), $font_array);

			return $array;

		}
		add_filter( 'ot_recognized_font_families', 'ot_filter_recognized_font_families', 1, 2 );

	endif;
	
function show_full_posts() {

	if (ot_get_option( 'excerpt_select') == 'full') return TRUE;
	else return FALSE;

}

function adjust_brighness($hex, $steps) {
    // Steps should be between -255 and 255. Negative = darker, positive = lighter
    $steps = max(-255, min(255, $steps));

    // Format the hex color string
    $hex = str_replace('#', '', $hex);
    if (strlen($hex) == 3) {
        $hex = str_repeat(substr($hex,0,1), 2).str_repeat(substr($hex,1,1), 2).str_repeat(substr($hex,2,1), 2);
    }

    // Get decimal values
    $r = hexdec(substr($hex,0,2));
    $g = hexdec(substr($hex,2,2));
    $b = hexdec(substr($hex,4,2));

    // Adjust number of steps and keep it inside 0 to 255
    $r = max(0,min(255,$r + $steps));
    $g = max(0,min(255,$g + $steps));  
    $b = max(0,min(255,$b + $steps));

    $r_hex = str_pad(dechex($r), 2, '0', STR_PAD_LEFT);
    $g_hex = str_pad(dechex($g), 2, '0', STR_PAD_LEFT);
    $b_hex = str_pad(dechex($b), 2, '0', STR_PAD_LEFT);

    return '#'.$r_hex.$g_hex.$b_hex;
}

function remove_cssjs_ver( $src ) {
    if( strpos( $src, '?ver=' ) )
        $src = remove_query_arg( 'ver', $src );
    return $src;
}

add_filter( 'style_loader_src', 'remove_cssjs_ver', 10, 2 );
add_filter( 'script_loader_src', 'remove_cssjs_ver', 10, 2 );
add_filter('wp_generate_tag_cloud', 'xf_tag_cloud',10,3);

function xf_tag_cloud($tag_string){
   return preg_replace("/style='font-size:.+pt;'/", '', $tag_string);
}


function create_post_type() {
	register_post_type( 'book',
		array(
			'labels' => array(
				'name' => __( 'Books', 'published' ),
				'singular_name' => __( 'Book', 'published' )
			),
		'public' => true
		)
	);
	add_post_type_support( 'book', 'thumbnail' );
	add_post_type_support( 'book', 'excerpt' );
} 

add_action( 'init', 'create_post_type' );

function display_buy_links($post) {

	$retailers = get_retailers();

	echo '<div id="buy-links"><p>'.__('Available at: ', 'published');

	$i = 0;
	$len = count($retailers);

	foreach($retailers as $id => $name) {

		$value = get_post_meta( get_the_ID(), 'published_'.$id.'_url', TRUE ); 

		if($value != '') {
			echo '<a class="buy-link" href="'.$value.'">'.$name.'</a> ';

			if ( $i == $len - 1) {

			} else {
				echo '&#124; ';	
			}

		}

		$i++;
	}

	echo '</p></div>';
				
}

function get_retailers() {

	$retailers = array(
		'amazon' => 'Amazon',
		'kobo' => 'Kobo',
		'bn' => 'Barnes & Noble',
		'amazon_uk' => 'Amazon UK',
		'download' => 'Free Download'
	);

	if ( function_exists( 'ot_get_option' ) ) {

	  /* get the slider array */
	  $retailers_custom = ot_get_option( 'retailers', array() );

	  if ( ! empty( $retailers_custom ) ) {
		foreach( $retailers_custom as $retailer ) {

			$name =  $retailer['retailer_name'];
			$id =  $retailer['retailer_id'];

			$retailers[ $id ] = $name;
		}
	  }

	}

	return $retailers;
}

				
function display_social_links() {

  $twitter = ot_get_option('twitter_url');
  $facebook = ot_get_option('facebook_url');
  $google = ot_get_option('google_url');
  $pinterest = ot_get_option('pinterest_url');
  $linkedin = ot_get_option('linkedin_url');
  $youtube = ot_get_option('youtube_url');
  $instagram = ot_get_option('instagram_url');
  $rss = ot_get_option('rss_url');

  $social_links = '<ul class="social">';

  if ($twitter != 'http://') { $social_links .= '<li><a class="social-icon twitter" target="_blank" href="'.$twitter.'"><span class="socicon socicon-twitter"></span></a></li>';}

  if ($facebook != 'http://') { $social_links .= '<li><a class="social-icon facebook" target="_blank" href="'.$facebook.'"><span class="socicon socicon-facebook"></span></a></li>'; }

  if ($google != 'http://') { $social_links .= '<li><a class="social-icon google" target="_blank" href="'.$google.'"><span class="socicon socicon-google"></span></a></li>'; }

  if ($linkedin != 'http://') { $social_links .= '<li><a class="social-icon linkedin" target="_blank" href="'.$linkedin.'"><span class="socicon socicon-linkedin"></span></a></li>'; }

  if ($youtube != 'http://') { $social_links .= '<li><a class="social-icon youtube" target="_blank" href="'.$youtube.'"><span class="socicon socicon-youtube"></span></a></li>'; }

  if ($instagram != 'http://') { $social_links .= '<li><a class="social-icon instagram" target="_blank" href="'.$instagram.'"><span class="socicon socicon-instagram"></span></a></li>'; }
  
  if ($rss != 'http://') { $social_links .= '<li><a class="social-icon rss" target="_blank" href="'.$rss.'"><span class="socicon socicon-rss"></span></a></li>'; }			

  if ($pinterest != 'http://') { $social_links .= '<li><a class="social-icon pinterest" target="_blank" href="'.$pinterest.'"><span class="socicon socicon-pinterest"></span></a></li>'; }				

  $social_links .= '</ul>';
  
  return $social_links;
  
} 
				
require_once('wp-updates-theme.php');

new WPUpdatesThemeUpdater_800( 'http://wp-updates.com/api/2/theme', basename( get_template_directory() ) );
								