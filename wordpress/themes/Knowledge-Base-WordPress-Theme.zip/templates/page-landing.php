<?php
/**
* Template Name: Landing Page Template
*/
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<link rel="shortcut icon" href="<?php echo esc_url( get_theme_mod('favicon', get_template_directory_uri().'/favicon.ico') ) ?>" />        
<?php wp_head(); ?>
</head>

<body <?php body_class('landing-page'); ?>>
		
<div id="page" class="hfeed site">
	
	<a class="skip-link screen-reader-text" href="#content">
		<?php _e( 'Skip to content', 'ot-apollo' ); ?>
	</a>

	<header id="masthead" class="site-header" role="banner">

			<div class="grid grid-pad">
				<div class="site-branding col-1-1">
					<?php if( $logo = get_theme_mod('logo_upload') ) : ?>
						
						<a href="<?php echo home_url(); ?>"><img src="<?php echo esc_url($logo) ?>"></a>
						
					<?php else : ?>
						
						<div class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></div>
						<?php $description = get_bloginfo( 'description' );
						if ( ! empty( $description ) ) : ?>
							<div class="divider">&#124;</div>
							<div class="site-description"><?php echo esc_html( $description ); ?></div>
						<?php endif; ?>

					<?php endif;?>		
				</div>
			</div>
				
		</div>

	</header>	
	
	<div id="content" class="site-content">

<div class="grid">

	<div id="primary" class="content-area col-8-12 push-2-12">
		
		<main id="main" class="site-main" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', 'page' ); ?>

				<?php
					// If comments are open or we have at least one comment, load up the comment template
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;
				?>

			<?php endwhile; // end of the loop. ?>

		</main><!-- #main -->
	</div><!-- #primary -->

	</div><!-- #content -->

	<div class="sub-footer">
		<div class="grid">

			<p>Powered by the <a href="<?php echo THEME_URL ?>">Apollo Theme</a></p>

		</div><!-- .site-info -->
	</div><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
