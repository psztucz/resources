<?php 

/**
 * Create the section
 */
function my_custom_section( $wp_customize ) {
	    
    // Create the "My Section" section
    $wp_customize->add_section( 'ot-general', array(
        'title'    => __( 'General Settings', 'ot-apollo' ),
        'priority' => 12
    ) );    
	
	$wp_customize->add_panel( 'panel_id', array(
	'priority' => 10,
	'capability' => 'edit_theme_options',
	'theme_supports' => '',
	'title' => __( 'Design Settings', 'ot-apollo' ),
	'description' => __( 'Customize the design of Apollo.', 'ot-apollo' ),
	) );

	// Create the "My Section" section
	$wp_customize->add_section( 'ot-header', array(
		'title'    => __( 'Header Design', 'ot-apollo' ),
		'priority' => 12,
		'panel' => 'panel_id',
	) );
	
	// Create the "My Section" section
	$wp_customize->add_section( 'ot-hero', array(
		'title'    => __( 'Hero Section Design', 'ot-apollo' ),
		'priority' => 12,
		'panel' => 'panel_id',
	) );

	// Create the "My Section" section
	$wp_customize->add_section( 'ot-callout', array(
		'title'    => __( 'Callout Design', 'ot-apollo' ),
		'priority' => 12,
		'panel' => 'panel_id',
	) );	
	
	// Create the "My Section" section
	$wp_customize->add_section( 'ot-footer', array(
		'title'    => __( 'Footer Design', 'ot-apollo' ),
		'priority' => 12,
		'panel' => 'panel_id',
	) );	
	
	// Create the "My Section" section
	$wp_customize->add_section( 'ot-accent', array(
		'title'    => __( 'Buttons and Links', 'ot-apollo' ),
		'priority' => 12,
		'panel' => 'panel_id',
	) );		
	
	// Create the "My Section" section
	$wp_customize->add_section( 'ot-fonts', array(
		'title'    => __( 'Fonts', 'ot-apollo' ),
		'priority' => 12,
		'panel' => 'panel_id',
		'description' => 'You can preview Google Fonts here - <a target="_blank" href="https://www.google.com/fonts/">https://www.google.com/fonts/</a>'
	) );			
		
	// Create the "My Section" section
	$wp_customize->add_section( 'ot-contact', array(
		'title'    => __( 'Contact Page', 'ot-apollo' ),
		'priority' => 12,
		'panel' => 'panel_id',
	) );			
	
}
add_action( 'customize_register', 'my_custom_section' );

/**
 * Create the setting
 */
function my_custom_setting( $controls ) {

    $controls[] = array(
        'type'     => 'image',
        'setting'  => 'favicon',
        'label'    => __( 'Favicon Upload', 'ot-apollo' ),
        'section'  => 'ot-general',
        'default'  => '',
        'priority' => 1,
        'transport' => 'refresh'
    );    
	
	
	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'custom_css',
		'label'    => __( 'Custom CSS', 'ot-apollo' ),
		'section'  => 'ot-general',
		'default'  => '',
		'priority' => 1,
		'transport' => 'refresh'
	);    
 
	$controls[] = array(
		'type'     => 'image',
		'setting'  => 'logo_upload',
		'label'    => __( 'Logo Image', 'ot-apollo' ),
		'section'  => 'ot-header',
		'default'  => '',
		'priority' => 1,
		'transport' => 'refresh'
	);			
	
	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'header_bg',
		'label'    => __( 'Header Background Color', 'ot-apollo' ),
		'section'  => 'ot-header',
		'default'  => '#212121',
		'priority' => 1,
		'description' => 'The following options won\'t be applied to the home page template.',
		'transport' => 'postMessage'
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'logo_color',
		'label'    => __( 'Logo Color', 'ot-apollo' ),
		'section'  => 'ot-header',
		'default'  => '#ffffff',
		'priority' => 1,
		'description' => 'This will be used if you don\'t upload a custom logo.',
		'transport' => 'postMessage'
	);	
	
	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'nav_color',
		'label'    => __( 'Navigation Color', 'ot-apollo' ),
		'section'  => 'ot-header',
		'default'  => '#AEAEAE',
		'priority' => 1,
		'transport' => 'postMessage'
	);

	$controls[] = array(
		'type'     => 'text',
		'setting'  => 'hero_headline',
		'label'    => __( 'Headline', 'ot-apollo' ),
		'section'  => 'ot-hero',
		'default'  => 'Create a Knowledge Base with Ease',
		'priority' => 1,
		'transport' => 'postMessage'
	);	
	
	
	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'hero_text',
		'label'    => __( 'Text', 'ot-apollo' ),
		'section'  => 'ot-hero',
		'default'  => 'Apollo allows you to create a knowledge base for your clients and customers. Knowledge bases are an extremely helpful and cost effective approach to customer support.',
		'priority' => 1,
		'transport' => 'postMessage'
	);		
	

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'hero_bg',
		'label'    => __( 'Background Color', 'ot-apollo' ),
		'section'  => 'ot-hero',
		'default'  => '#212121',
		'priority' => 1,
		'transport' => 'postMessage',
		'description' => __( 'The solid color background will be shown if no image or video is chosen.', 'ot-apollo' )

	);		
	
	$controls[] = array(
		'type'     => 'image',
		'setting'  => 'hero_image',
		'label'    => __( 'Image Background', 'ot-apollo' ),
		'section'  => 'ot-hero',
		'default'  => '',
		'priority' => 1,
		'transport' => 'postMessage',
		'description' => __( 'The background image will be shown if no video is chosen, or the video is still loading.', 'ot-apollo' )

	);		
	
	$controls[] = array(
		'type'     => 'image',
		'setting'  => 'hero_video',
		'label'    => __( 'Video Background', 'ot-apollo' ),
		'section'  => 'ot-hero',
		'default'  => '',
		'priority' => 1,
	);
	
	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'footer_bg',
		'label'    => __( 'Footer Background Color', 'ot-apollo' ),
		'section'  => 'ot-footer',
		'default'  => '#212121',
		'priority' => 1,
		'transport' => 'postMessage'
	);		

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'callout_bg',
		'label'    => __( 'Callout Background Color', 'ot-apollo' ),
		'section'  => 'ot-callout',
		'default'  => '#016893',
		'priority' => 1,
		'transport' => 'postMessage'
	);			

	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'callout_text',
		'label'    => __( 'Callout Text', 'ot-apollo' ),
		'section'  => 'ot-callout',
		'default'  => '',
		'priority' => 1,
		'transport' => 'postMessage'
	);	
	
	$controls[] = array(
		'type'     => 'text',
		'setting'  => 'callout_button_text',
		'label'    => __( 'Button Text', 'ot-apollo' ),
		'section'  => 'ot-callout',
		'default'  => '',
		'priority' => 1,
		'transport' => 'postMessage'
	);	
	
		$controls[] = array(
		'type'     => 'text',
		'setting'  => 'callout_button_url',
		'label'    => __( 'Button URL', 'ot-apollo' ),
		'section'  => 'ot-callout',
		'default'  => 'http://',
		'priority' => 1,
		'transport' => 'postMessage'
	);	
	
	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'sub_footer_bg',
		'label'    => __( 'Sub Footer Background Color', 'ot-apollo' ),
		'section'  => 'ot-footer',
		'default'  => '#181818',
		'priority' => 1,
		'transport' => 'postMessage'
	);		

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'link_color',
		'label'    => __( 'Link Color', 'ot-apollo' ),
		'section'  => 'ot-accent',
		'default'  => '#016893',
		'priority' => 1,
		'transport' => 'postMessage'
	);			

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'button_bg',
		'label'    => __( 'Button Background Color', 'ot-apollo' ),
		'section'  => 'ot-accent',
		'default'  => '#016893',
		'priority' => 1,
		'transport' => 'postMessage'
	);	
	
	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'button_color',
		'label'    => __( 'Button Text Color', 'ot-apollo' ),
		'section'  => 'ot-accent',
		'default'  => '#ffffff',
		'priority' => 1,
		'transport' => 'postMessage'
	);		
	
	$font_choices = Kirki_Fonts::get_font_choices();
	
	$controls[] = array(
		'type'     => 'select',
		'setting'  => 'primary_font',
		'label'    => __( 'Primary Font', 'ot-apollo' ),
		'section'  => 'ot-fonts',
		'default'  => 'Open Sans',
		'priority' => 1,
		'choices'  => $font_choices,
		'transport' => 'refresh'
	);
	
	$controls[] = array(
		'type'     => 'select',
		'setting'  => 'secondary_font',
		'label'    => __( 'Secondary Font', 'ot-apollo' ),
		'section'  => 'ot-fonts',
		'default'  => 'Open Sans',
		'priority' => 1,
		'choices'  => $font_choices,
		'transport' => 'refresh'
	);	
		
	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'map_url',
		'label'    => __( 'Google Maps URL', 'ot-apollo' ),
		'section'  => 'ot-contact',
		'default'  => '',
		'priority' => 1,
	);	
	
	return $controls;
}
add_filter( 'kirki/controls', 'my_custom_setting' );
