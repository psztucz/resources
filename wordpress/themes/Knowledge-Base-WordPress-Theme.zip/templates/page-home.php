<?php
/**
* Template Name: Home Template
*/

$hero_image = get_theme_mod('hero_image');
$video_url = get_theme_mod('hero_video');
$hero_headline = get_theme_mod('hero_headline');
$hero_text = get_theme_mod('hero_text');

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">     
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
		
<div id="page" class="hfeed site">
	
	<a class="skip-link screen-reader-text" href="#content">
		<?php _e( 'Skip to content', 'ot-apollo' ); ?>
	</a>

	
	<div id="content" class="site-content">

		<div class="hero">
			<div class="video">
				<?php get_template_part( 'partials/header' ); ?>	
				<div class="grid">
					<div class="col-2-3 hero-inner">

						<?php if($hero_headline) : ?>
							<h1 class="hero-title"><?php echo esc_html($hero_headline); ?></h1>
						<?php endif; ?>

						<?php if($hero_text) : ?>
							<p class="hero-text"><?php echo esc_html($hero_text); ?></p>
						<?php endif; ?>

						<form class="hero-search" action="<?php echo esc_url( home_url() ); ?>">
							<input class="hero-input" type="text" name="s" placeholder="Search the knowledge base..." />
							<input class="hero-button apollo-button" type="submit" value="Search" />
						</form>

					</div>
				</div>

				<?php if( $video_url || $hero_image ) : ?>
					<video class="video-background" autoplay loop >
						<source src="<?php echo esc_url($video_url); ?>" type="video/mp4">
					</video>
				<?php endif; ?>
			</div>
		</div>

		<div class="grid cards">

			<?php

			if ( function_exists('knowledge_cpt') ) :

				$sections = get_terms( 'section', 'parent=0' );

				foreach($sections as $id => $section) {

						if( ! empty($section) ) {		

							echo '<div class="section-intro col-1-1 inline-block">';
							echo '<h2 class="section-heading">' . $section->name . '</h2>';
							echo '<p class="section-description">' . $section->description . '</p>';
							echo '</div>';

							$args = array(
								'child_of'         => $section->term_id
							); 

							$children = get_terms('section', $args);

							if ( ! empty( $children ) && ! is_wp_error( $children ) ){

								foreach ( $children as $child ) {

									$term_link = get_term_link( $child );

									echo '<div class="section-card col-1-3 inline-block">';
									echo '<a href="' . esc_url( $term_link ) . '">';
									echo '<div class="card-inner">';
									echo '<h3 class="card-heading">'.$child->name.'</h3>';
									echo '<p class="card-description">'.$child->description.'</p>';
									echo '<p class="card-count">';
										printf( _n( '1 Article', '%d Articles', $child->count, 'apollo' ), $child->count );
									echo '</p>';
									echo '</div>';
									echo '</a>';
									echo '</div>';


									}
							}

						}

				}

			endif;

			?>

		</div>
				
<?php get_footer(); ?>