<?php


add_action('wp_footer', 'custom_stylesheet_content');

function custom_stylesheet_content() {

	$custom_css = ot_get_option( 'custom_css');

	$header_color = ot_get_option( 'header_color'); 
	$accent_color = ot_get_option( 'accent_color');
	$footer_color = ot_get_option( 'footer_color');

	$paragraph_font = ot_get_option( 'paragraph_font');
	$title_font = ot_get_option( 'title_font'); 
	$sidebar_heading = ot_get_option( 'sidebar_heading');
	$sidebar_font = ot_get_option( 'sidebar_font');
	$navigation_font = ot_get_option( 'navigation_font');

	
 ?>
 
 <style type="text/css">

 <?php 
 
 if ( $header_color != '' ) { echo '#masthead, .home #below-header {background:'.$header_color.'}'; } 
 if ( $accent_color != '' ) { echo 'a {color:'.$accent_color.'} a:hover, a:active, a:focus {color:'.adjust_brighness($accent_color,'-50').'} .button, .flexslider .flex-next:hover, .flexslider .flex-prev:hover, .tagcloud a, .back-to-top img:hover {background-color:'.$accent_color.';} .button:hover, .tagcloud a:hover {background:'.adjust_brighness($accent_color,'-50').'}'; } 
 if ( $footer_color != '' ) { echo '.site-footer {background:'.$footer_color.'}'; } 
 
  if ( is_array( $paragraph_font ) ) { echo 'p { 
  color:'.$paragraph_font['font-color'].';
  font-family:'.$paragraph_font['font-family'].';
  font-size:'.$paragraph_font['font-size'].';
  font-weight:'.$paragraph_font['font-weight'].';
  }'; } 

  if ( is_array( $title_font ) ) { echo 'h1, h2, h3, h4, h5, h6 { 
  color:'.$title_font['font-color'].';
  font-family:'.$title_font['font-family'].';
  font-size:'.$title_font['font-size'].';
  font-weight:'.$title_font['font-weight'].';
  }'; } 
  
  if ( is_array( $sidebar_heading ) ) { echo '.widget-title { 
  color:'.$sidebar_heading['font-color'].';
  font-family:'.$sidebar_heading['font-family'].';
  font-size:'.$sidebar_heading['font-size'].';
  font-weight:'.$sidebar_heading['font-weight'].';
  }'; } 
  
  if ( is_array( $sidebar_font ) ) { echo '#secondary p, #secondary ul, #secondary ol { 
  color:'.$sidebar_font['font-color'].';
  font-family:'.$sidebar_font['font-family'].';
  font-size:'.$sidebar_font['font-size'].';
  font-weight:'.$sidebar_font['font-weight'].';
  }'; } 
  
  if ( is_array( $navigation_font ) ) { echo '.navigation ul { 
  color:'.$navigation_font['font-color'].';
  font-family:'.$navigation_font['font-family'].';
  font-size:'.$navigation_font['font-size'].';
  font-weight:'.$navigation_font['font-weight'].';
  }'; } 

 
  echo $custom_css; 
 
  echo '</style>';
      
 } ?>