<?php
/**
 * published functions and definitions
 *
 * @package published
 */
if ( ! isset( $content_width ) ) {	$content_width = 610;}

if ( ! function_exists( 'published_setup' ) ) :

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function published_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 */
	load_theme_textdomain( 'ot-published', get_template_directory() . '/languages' );

	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'ot-published' ),
	) );

	// Enable support for HTML5 markup.
	add_theme_support( 'html5', array(
		'comment-list',
		'search-form',
		'comment-form',
		'gallery',
	) );
	
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	
	add_image_size( 'homepage-thumb', 150, 150, true );
	add_image_size( 'single-feature', 690); 
	add_image_size( 'book-thumb', 150); 
	add_image_size( 'book-thumb', 300); 
	add_image_size( 'book-full', 500); 
}
endif; 

add_action( 'after_setup_theme', 'published_setup' );

/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function published_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'ot-published' ),
		'id'            => 'sidebar-1',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Left', 'ot-published' ),
		'id'            => 'footer-left',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Middle', 'ot-published' ),
		'id'            => 'footer-middle',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Right', 'ot-published' ),
		'id'            => 'footer-right',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'published_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function published_scripts() {
	wp_enqueue_style( 'published-style', get_stylesheet_uri() );
	wp_enqueue_style( 'published-design', get_template_directory_uri() . '/css/published.css' );
	wp_enqueue_style( 'published-fonts', 'http://fonts.googleapis.com/css?family=Lato:400,700,900,400italic|Bitter:400,900,700,400italic' );
	wp_enqueue_style( 'published-icons', get_template_directory_uri() . '/css/font-awesome.min.css'  );
	wp_enqueue_style( 'published-responsive', get_template_directory_uri() . '/css/responsive.css' );
	wp_enqueue_script( 'jquery' );	
	wp_enqueue_script( 'published-code', get_template_directory_uri() . '/js/jquery.snippet.min.js' );
	wp_enqueue_script( 'published-tinynav', get_template_directory_uri() . '/js/tinynav.min.js' );
	wp_enqueue_script( 'published-custom', get_template_directory_uri() . '/js/custom.js' );
	wp_enqueue_script( 'bapublishedse-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	
}
add_action( 'wp_enqueue_scripts', 'published_scripts' );


require get_template_directory() . '/inc/css.php';
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/extras.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/jetpack.php';
require get_template_directory() . '/inc/shortcodes.php';
require get_template_directory() . '/inc/widgets/social-widget.php';

require  get_template_directory() . '/inc/option-tree/ot-loader.php';
require  get_template_directory() . '/theme-options/functions.php';
require  get_template_directory() . '/theme-options/meta-boxes.php';
require  get_template_directory() . '/theme-options/options.php';



function adjust_brighness($hex, $steps) {
    // Steps should be between -255 and 255. Negative = darker, positive = lighter
    $steps = max(-255, min(255, $steps));

    // Format the hex color string
    $hex = str_replace('#', '', $hex);
    if (strlen($hex) == 3) {
        $hex = str_repeat(substr($hex,0,1), 2).str_repeat(substr($hex,1,1), 2).str_repeat(substr($hex,2,1), 2);
    }

    // Get decimal values
    $r = hexdec(substr($hex,0,2));
    $g = hexdec(substr($hex,2,2));
    $b = hexdec(substr($hex,4,2));

    // Adjust number of steps and keep it inside 0 to 255
    $r = max(0,min(255,$r + $steps));
    $g = max(0,min(255,$g + $steps));  
    $b = max(0,min(255,$b + $steps));

    $r_hex = str_pad(dechex($r), 2, '0', STR_PAD_LEFT);
    $g_hex = str_pad(dechex($g), 2, '0', STR_PAD_LEFT);
    $b_hex = str_pad(dechex($b), 2, '0', STR_PAD_LEFT);

    return '#'.$r_hex.$g_hex.$b_hex;
}


add_filter('wp_generate_tag_cloud', 'xf_tag_cloud',10,3);

function xf_tag_cloud($tag_string){
   return preg_replace("/style='font-size:.+pt;'/", '', $tag_string);
}


function create_post_type() {
	register_post_type( 'book',
		array(
			'labels' => array(
				'name' => __( 'Books', 'ot-published' ),
				'singular_name' => __( 'Book', 'ot-published' )
			),
		'public' => true
		)
	);
	add_post_type_support( 'book', 'thumbnail' );
	add_post_type_support( 'book', 'excerpt' );
} 

add_action( 'init', 'create_post_type' );

function display_buy_links($post) {

	$retailers = get_retailers();

	echo '<div id="buy-links"><p>'.__('Available at: ', 'ot-published');


	foreach($retailers as $id => $name) {

		$value = get_post_meta( get_the_ID(), 'published_'.$id.'_url', TRUE ); 

		if($value != '') {
			echo '<a class="buy-link" href="' .esc_url( $value) . '">'.$name.'</a> ';

		}

	}

	echo '</p></div>';
				
}

function get_retailers() {

	$retailers = array(
		'amazon' => 'Amazon',
		'kobo' => 'Kobo',
		'bn' => 'Barnes & Noble',
		'amazon_uk' => 'Amazon UK',
		'download' => 'Free Download'
	);

	if ( function_exists( 'ot_get_option' ) ) {

	  /* get the slider array */
	  $retailers_custom = ot_get_option( 'retailers', array() );

	  if ( ! empty( $retailers_custom ) ) {
		foreach( $retailers_custom as $retailer ) {

			$name =  $retailer['retailer_name'];
			$id =  $retailer['retailer_id'];

			$retailers[ $id ] = $name;
		}
	  }

	}

	return $retailers;
}

				

				
require_once('inc/wp-updates-theme.php');

new WPUpdatesThemeUpdater_800( 'http://wp-updates.com/api/2/theme', basename( get_template_directory() ) );





/* 
 * Change Meta Box visibility according to Page Template
 *
 */

add_action('admin_head', 'ot_published_meta_box_hide');

function ot_published_meta_box_hide() {
    global $current_screen;
    if('page' != $current_screen->id) return;

    echo <<<HTML
        <script type="text/javascript">
        jQuery(document).ready( function($) {

            /**
             * Adjust visibility of the meta box at startup
            */
            if($('#page_template').val() == 'page-templates/contact-page.php') {
                // show the meta box
                $('#contact_meta_box').show();
            } else {
                // hide your meta box
                $('#contact_meta_box').hide();
            }

            // Debug only
            // - outputs the template filename
            // - checking for console existance to avoid js errors in non-compliant browsers
            if (typeof console == "object") 
                console.log ('default value = ' + $('#page_template').val());

            /**
             * Live adjustment of the meta box visibility
            */
            $('#page_template').live('change', function(){
                    if($(this).val() == 'page-templates/contact-page.php') {
                    // show the meta box
                    $('#contact_meta_box').show();
                } else {
                    // hide your meta box
                    $('#contact_meta_box').hide();
                }

                // Debug only
                if (typeof console == "object") 
                    console.log ('live change value = ' + $(this).val());
            });                 
        });    
        </script>
HTML;
}
								