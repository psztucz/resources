<?php
/**
 * Custom Widgets
 *
 * @package fotok
 * @since fotok 1.0
 */

/**
 * Contact
 *
 * @since fotok 1.0
 */
class contact_fotok extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	function contact_fotok() {
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'widget-contact', 'description' => 'Contact\'s Details Widget for fotok.', 'fotok' );

		/* Widget control settings. */
		$control_ops = array( 'id_base' => 'contact_fotok' );

		/* Create the widget. */
		$this->WP_Widget( 'contact_fotok', 'Contact Details (fotok)', $widget_ops, $control_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	function widget( $args, $instance ) {
		extract( $args );

		/* User-selected settings. */
		$title = apply_filters( 'widget_title', $instance['title'] );
		$name = $instance['name'];
		$telephone = $instance['telephone'];
		$email = $instance['email'];
		$place = $instance['place'];

		/* Before widget (defined by themes). */
		echo $before_widget;

		if ( $title )
			echo $before_title . $title . $after_title;

		if ( $name )
			echo '<p><b>' . $name . '</b></p>';

		if ( $telephone )
			echo '<p>Tel: ' . $telephone . '</p>';

		if ( $email )
			echo '<p>email: ' . $email . '</p>';

		if ( $place )
			echo '<p>' . $place . '.</p>';

		/* After widget (defined by themes). */
		echo $after_widget;
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags (if needed) and update the widget settings. */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['name'] = $new_instance['name'];
		$instance['telephone'] = $new_instance['telephone'];
		$instance['email'] = $new_instance['email'];
		$instance['place'] = $new_instance['place'];

		return $instance;
	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array( 
						'title' => 'Contact Details', 
						'name' => 'PanKogut', 
						'telephone' => '+44 1234 567890',  
						'email' => 'hello@pankogut.com', 
						'place' => 'London, UK'
					);
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'name' ); ?>"><?php _e('Your Name:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'name' ); ?>" name="<?php echo $this->get_field_name( 'name' ); ?>" value="<?php echo $instance['name']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'telephone' ); ?>"><?php _e('Your Telephone:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'telephone' ); ?>" name="<?php echo $this->get_field_name( 'telephone' ); ?>" value="<?php echo $instance['telephone']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'email' ); ?>"><?php _e('Your Email:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'email' ); ?>" name="<?php echo $this->get_field_name( 'email' ); ?>" value="<?php echo $instance['email']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'place' ); ?>"><?php _e('Where do you live?:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'place' ); ?>" name="<?php echo $this->get_field_name( 'place' ); ?>" value="<?php echo $instance['place']; ?>" style="width:100%;" />
		</p>

		<?php
	}

}

function register_contact_fotok() {
    register_widget( 'contact_fotok' );
}
add_action( 'widgets_init', 'register_contact_fotok' );

/**
 * Social Links
 *
 * @since fotok 1.0
 */
class social_fotok extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	function social_fotok() {
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'widget-social', 'description' => 'Show Icons of your Social Links.', 'fotok' );

		/* Widget control settings. */
		$control_ops = array( 'id_base' => 'social_fotok' );

		/* Create the widget. */
		$this->WP_Widget( 'social_fotok', 'Social Links (fotok)', $widget_ops, $control_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	function widget( $args, $instance ) {
		extract( $args );

		/* User-selected settings. */
		$title = apply_filters( 'widget_title', $instance['title'] );
		$feed = $instance['feed'];
		$linkedin = $instance['linkedin'];
		$twitter = $instance['twitter'];
		$facebook = $instance['facebook'];
		$googleplus = $instance['googleplus'];
		$pinterest = $instance['pinterest'];
		$instagram = $instance['instagram'];
		$flickr = $instance['flickr'];
		$youtube = $instance['youtube'];
		$vimeo = $instance['vimeo'];
		$dribbble = $instance['dribbble'];
		$behance = $instance['behance'];
		$github = $instance['github'];
		$skype = $instance['skype'];
		$tumblr = $instance['tumblr'];
		$wordpress = $instance['wordpress'];


		/* Before widget (defined by themes). */
		echo $before_widget;

		if ( $title )
			echo $before_title . $title . $after_title;

		if ( $feed )
			echo '<a href="' . $feed . '" title="' . __( 'Feed', 'fotok' ) . '" class="' . __( 'social social-feed', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $linkedin )
			echo '<a href="' . $linkedin . '" title="' . __( 'Linkedin', 'fotok' ) . '" class="' . __( 'social social-linkedin', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $twitter )
			echo '<a href="' . $twitter . '" title="' . __( 'Twitter', 'fotok' ) . '" class="' . __( 'social social-twitter', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $facebook )
			echo '<a href="' . $facebook . '" title="' . __( 'Facebook', 'fotok' ) . '" class="' . __( 'social social-facebook', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $googleplus )
			echo '<a href="' . $googleplus . '" title="' . __( 'Googleplus', 'fotok' ) . '" class="' . __( 'social social-googleplus', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $pinterest )
			echo '<a href="' . $pinterest . '" title="' . __( 'Pinterest', 'fotok' ) . '" class="' . __( 'social social-pinterest', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $instagram )
			echo '<a href="' . $instagram . '" title="' . __( 'Instagram', 'fotok' ) . '" class="' . __( 'social social-instagram', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $flickr )
			echo '<a href="' . $flickr . '" title="' . __( 'Flickr', 'fotok' ) . '" class="' . __( 'social social-flickr', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $youtube )
			echo '<a href="' . $youtube . '" title="' . __( 'Youtube', 'fotok' ) . '" class="' . __( 'social social-youtube', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $vimeo )
			echo '<a href="' . $vimeo . '" title="' . __( 'Vimeo', 'fotok' ) . '" class="' . __( 'social social-vimeo', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $dribbble )
			echo '<a href="' . $dribbble . '" title="' . __( 'Dribbble', 'fotok' ) . '" class="' . __( 'social social-dribbble', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $behance )
			echo '<a href="' . $behance . '" title="' . __( 'Behance', 'fotok' ) . '" class="' . __( 'social social-behance', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $github )
			echo '<a href="' . $github . '" title="' . __( 'Github', 'fotok' ) . '" class="' . __( 'social social-github', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $skype )
			echo '<a href="' . $skype . '" title="' . __( 'Skype', 'fotok' ) . '" class="' . __( 'social social-skype', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $tumblr )
			echo '<a href="' . $tumblr . '" title="' . __( 'Tumblr', 'fotok' ) . '" class="' . __( 'social social-tumblr', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';

		if ( $wordpress )
			echo '<a href="' . $wordpress . '" title="' . __( 'Wordpress', 'fotok' ) . '" class="' . __( 'social social-wordpress', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>';
		
		/* After widget (defined by themes). */
		echo $after_widget;
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags (if needed) and update the widget settings. */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['feed'] = $new_instance['feed'];
		$instance['linkedin'] = $new_instance['linkedin'];
		$instance['twitter'] = $new_instance['twitter'];
		$instance['facebook'] = $new_instance['facebook'];
		$instance['googleplus'] = $new_instance['googleplus'];
		$instance['pinterest'] = $new_instance['pinterest'];
		$instance['instagram'] = $new_instance['instagram'];
		$instance['flickr'] = $new_instance['flickr'];
		$instance['youtube'] = $new_instance['youtube'];
		$instance['vimeo'] = $new_instance['vimeo'];
		$instance['dribbble'] = $new_instance['dribbble'];
		$instance['behance'] = $new_instance['behance'];
		$instance['github'] = $new_instance['github'];
		$instance['skype'] = $new_instance['skype'];
		$instance['tumblr'] = $new_instance['tumblr'];
		$instance['wordpress'] = $new_instance['wordpress'];

		return $instance;
	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array( 
						'title' => 'Social Links', 
						'feed' => 'http://www.website.com/feed/', 
						'linkedin' => '',
						'twitter' => '',
						'facebook' => '',
						'googleplus' => '',
						'pinterest' => '',
						'instagram' => '',
						'flickr' => '',
						'youtube' => '',
						'vimeo' => '',
						'dribbble' => '',
						'behance' => '',
						'github' => '',
						'skype' => '',
						'tumblr' => '',
						'tumblr' => ''
					);
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'feed' ); ?>"><?php _e('Feed:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'feed' ); ?>" name="<?php echo $this->get_field_name( 'feed' ); ?>" value="<?php echo $instance['feed']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'linkedin' ); ?>"><?php _e('Linkedin:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'linkedin' ); ?>" name="<?php echo $this->get_field_name( 'linkedin' ); ?>" value="<?php echo $instance['linkedin']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'twitter' ); ?>"><?php _e('Twitter:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'twitter' ); ?>" name="<?php echo $this->get_field_name( 'twitter' ); ?>" value="<?php echo $instance['twitter']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'facebook' ); ?>"><?php _e('Facebook:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'facebook' ); ?>" name="<?php echo $this->get_field_name( 'facebook' ); ?>" value="<?php echo $instance['facebook']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'googleplus' ); ?>"><?php _e('Googleplus:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'googleplus' ); ?>" name="<?php echo $this->get_field_name( 'googleplus' ); ?>" value="<?php echo $instance['googleplus']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'pinterest' ); ?>"><?php _e('Pinterest:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'pinterest' ); ?>" name="<?php echo $this->get_field_name( 'pinterest' ); ?>" value="<?php echo $instance['pinterest']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'instagram' ); ?>"><?php _e('Instagram:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'instagram' ); ?>" name="<?php echo $this->get_field_name( 'instagram' ); ?>" value="<?php echo $instance['instagram']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'flickr' ); ?>"><?php _e('Flickr:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'flickr' ); ?>" name="<?php echo $this->get_field_name( 'flickr' ); ?>" value="<?php echo $instance['flickr']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'youtube' ); ?>"><?php _e('Youtube:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'youtube' ); ?>" name="<?php echo $this->get_field_name( 'youtube' ); ?>" value="<?php echo $instance['youtube']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'vimeo' ); ?>"><?php _e('Vimeo:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'vimeo' ); ?>" name="<?php echo $this->get_field_name( 'vimeo' ); ?>" value="<?php echo $instance['vimeo']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'dribbble' ); ?>"><?php _e('Dribbble:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'dribbble' ); ?>" name="<?php echo $this->get_field_name( 'dribbble' ); ?>" value="<?php echo $instance['dribbble']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'behance' ); ?>"><?php _e('Behance:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'behance' ); ?>" name="<?php echo $this->get_field_name( 'behance' ); ?>" value="<?php echo $instance['behance']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'github' ); ?>"><?php _e('Github:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'github' ); ?>" name="<?php echo $this->get_field_name( 'github' ); ?>" value="<?php echo $instance['github']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'skype' ); ?>"><?php _e('Skype:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'skype' ); ?>" name="<?php echo $this->get_field_name( 'skype' ); ?>" value="<?php echo $instance['skype']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'tumblr' ); ?>"><?php _e('Tumblr:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'tumblr' ); ?>" name="<?php echo $this->get_field_name( 'tumblr' ); ?>" value="<?php echo $instance['tumblr']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'wordpress' ); ?>"><?php _e('Wordpress:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'wordpress' ); ?>" name="<?php echo $this->get_field_name( 'wordpress' ); ?>" value="<?php echo $instance['wordpress']; ?>" style="width:100%;" />
		</p>

		<?php
	}

}

function register_social_fotok() {
    register_widget( 'social_fotok' );
}
add_action( 'widgets_init', 'register_social_fotok' );

/**
 * About Widget
 *
 * @since fotok 1.0
 */
class about_fotok extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	function about_fotok() {
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'widget-about', 'description' => 'About Widget with your image and description. Use it on the Front Page Sidebar.', 'fotok' );

		/* Widget control settings. */
		$control_ops = array( 'id_base' => 'about_fotok' );

		/* Create the widget. */
		$this->WP_Widget( 'about_fotok', 'About (fotok)', $widget_ops, $control_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	function widget( $args, $instance ) {
		extract( $args );

		/* User-selected settings. */
		$title = apply_filters( 'widget_title', $instance['title'] );
		$imageurl = $instance['imageurl'];
		$imagealt = $instance['imagealt'];
		$imagewidth = $instance['imagewidth'];
		$imageheight = $instance['imageheight'];
		$aboutdescription = $instance['aboutdescription'];
		$feed = $instance['feed'];
		$linkedin = $instance['linkedin'];
		$twitter = $instance['twitter'];
		$facebook = $instance['facebook'];
		$googleplus = $instance['googleplus'];
		$pinterest = $instance['pinterest'];
		$instagram = $instance['instagram'];
		$flickr = $instance['flickr'];
		$youtube = $instance['youtube'];
		$vimeo = $instance['vimeo'];
		$dribbble = $instance['dribbble'];
		$behance = $instance['behance'];
		$github = $instance['github'];
		$skype = $instance['skype'];
		$tumblr = $instance['tumblr'];
		$wordpress = $instance['wordpress'];

		echo $before_widget; 
		?>

			<div class="about-description">
				<?php if($title != '') echo '<h3 class="about-title">'.$title.'</h3>'; ?>
				<p><?php echo $aboutdescription; ?></p>
				<p> Follow me on: 
					<?php if($feed != '') echo '<a href="' . $feed . '" title="' . __( 'Feed', 'fotok' ) . '" class="' . __( 'social social-feed', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($linkedin != '') echo '<a href="' . $linkedin . '" title="' . __( 'Linkedin', 'fotok' ) . '" class="' . __( 'social social-linkedin', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($twitter != '') echo '<a href="' . $twitter . '" title="' . __( 'Twitter', 'fotok' ) . '" class="' . __( 'social social-twitter', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($facebook != '') echo '<a href="' . $facebook . '" title="' . __( 'Facebook', 'fotok' ) . '" class="' . __( 'social social-facebook', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($googleplus != '') echo '<a href="' . $googleplus . '" title="' . __( 'Googleplus', 'fotok' ) . '" class="' . __( 'social social-googleplus', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($pinterest != '') echo '<a href="' . $pinterest . '" title="' . __( 'Pinterest', 'fotok' ) . '" class="' . __( 'social social-pinterest', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($instagram != '') echo '<a href="' . $instagram . '" title="' . __( 'Instagram', 'fotok' ) . '" class="' . __( 'social social-instagram', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($flickr != '') echo '<a href="' . $flickr . '" title="' . __( 'Flickr', 'fotok' ) . '" class="' . __( 'social social-flickr', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($youtube != '') echo '<a href="' . $youtube . '" title="' . __( 'Youtube', 'fotok' ) . '" class="' . __( 'social social-youtube', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($vimeo != '') echo '<a href="' . $vimeo . '" title="' . __( 'Vimeo', 'fotok' ) . '" class="' . __( 'social social-vimeo', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($dribbble != '') echo '<a href="' . $dribbble . '" title="' . __( 'Dribbble', 'fotok' ) . '" class="' . __( 'social social-dribbble', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($behance != '') echo '<a href="' . $behance . '" title="' . __( 'Behance', 'fotok' ) . '" class="' . __( 'social social-behance', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($github != '') echo '<a href="' . $github . '" title="' . __( 'Github', 'fotok' ) . '" class="' . __( 'social social-github', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($skype != '') echo '<a href="' . $skype . '" title="' . __( 'Skype', 'fotok' ) . '" class="' . __( 'social social-skype', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($tumblr != '') echo '<a href="' . $tumblr . '" title="' . __( 'Tumblr', 'fotok' ) . '" class="' . __( 'social social-tumblr', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
					<?php if($wordpress != '') echo '<a href="' . $wordpress . '" title="' . __( 'Wordpress', 'fotok' ) . '" class="' . __( 'social social-wordpress', 'fotok' ) . '" target="' . __( '_blank', 'fotok' ) . '"></a>'; ?>
				</p>
			</div>
			<div class="about-image">
				<img src="<?php echo $imageurl; ?>" width="<?php echo $imagewidth; ?>" height="<?php echo $imageheight; ?>" class="about-img" alt="<?php echo $imagealt; ?>">
			</div>

		<?php
		echo $after_widget;
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags (if needed) and update the widget settings. */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['imageurl'] = $new_instance['imageurl'];
		$instance['imagealt'] = $new_instance['imagealt'];
		$instance['imagewidth'] = $new_instance['imagewidth'];
		$instance['imageheight'] = $new_instance['imageheight'];
		$instance['aboutdescription'] = $new_instance['aboutdescription'];
		$instance['feed'] = $new_instance['feed'];
		$instance['linkedin'] = $new_instance['linkedin'];
		$instance['twitter'] = $new_instance['twitter'];
		$instance['facebook'] = $new_instance['facebook'];
		$instance['googleplus'] = $new_instance['googleplus'];
		$instance['pinterest'] = $new_instance['pinterest'];
		$instance['instagram'] = $new_instance['instagram'];
		$instance['flickr'] = $new_instance['flickr'];
		$instance['youtube'] = $new_instance['youtube'];
		$instance['vimeo'] = $new_instance['vimeo'];
		$instance['dribbble'] = $new_instance['dribbble'];
		$instance['behance'] = $new_instance['behance'];
		$instance['github'] = $new_instance['github'];
		$instance['skype'] = $new_instance['skype'];
		$instance['tumblr'] = $new_instance['tumblr'];
		$instance['wordpress'] = $new_instance['wordpress'];

		return $instance;
	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array( 
						'title' => 'About Me', 
						'imageurl' => 'http://...', 
						'imagealt' => '',  
						'imagewidth' => 'px', 
						'imageheight' => 'px',
						'aboutdescription' => '',
						'feed' => 'http://www.website.com/feed/', 
						'linkedin' => '',
						'twitter' => '',
						'facebook' => '',
						'googleplus' => '',
						'pinterest' => '',
						'instagram' => '',
						'flickr' => '',
						'youtube' => '',
						'vimeo' => '',
						'dribbble' => '',
						'behance' => '',
						'github' => '',
						'skype' => '',
						'tumblr' => '',
						'tumblr' => ''
					);
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'imageurl' ); ?>"><?php _e('Image URL:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'imageurl' ); ?>" name="<?php echo $this->get_field_name( 'imageurl' ); ?>" value="<?php echo $instance['imageurl']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'imagealt' ); ?>"><?php _e('Image ALT:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'imagealt' ); ?>" name="<?php echo $this->get_field_name( 'imagealt' ); ?>" value="<?php echo $instance['imagealt']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'imagewidth' ); ?>"><?php _e('Image Width:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'imagewidth' ); ?>" name="<?php echo $this->get_field_name( 'imagewidth' ); ?>" value="<?php echo $instance['imagewidth']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'imageheight' ); ?>"><?php _e('Image Height:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'imageheight' ); ?>" name="<?php echo $this->get_field_name( 'imageheight' ); ?>" value="<?php echo $instance['imageheight']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'aboutdescription' ); ?>"><?php _e('About Description:','fotok'); ?></label>
			<textarea id="<?php echo $this->get_field_id( 'aboutdescription' ); ?>" name="<?php echo $this->get_field_name( 'aboutdescription' ); ?>" rows="12" cols="20" style="width:100%;"><?php echo $instance['aboutdescription']; ?></textarea>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'feed' ); ?>"><?php _e('Feed:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'feed' ); ?>" name="<?php echo $this->get_field_name( 'feed' ); ?>" value="<?php echo $instance['feed']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'linkedin' ); ?>"><?php _e('Linkedin:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'linkedin' ); ?>" name="<?php echo $this->get_field_name( 'linkedin' ); ?>" value="<?php echo $instance['linkedin']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'twitter' ); ?>"><?php _e('Twitter:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'twitter' ); ?>" name="<?php echo $this->get_field_name( 'twitter' ); ?>" value="<?php echo $instance['twitter']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'facebook' ); ?>"><?php _e('Facebook:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'facebook' ); ?>" name="<?php echo $this->get_field_name( 'facebook' ); ?>" value="<?php echo $instance['facebook']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'googleplus' ); ?>"><?php _e('Googleplus:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'googleplus' ); ?>" name="<?php echo $this->get_field_name( 'googleplus' ); ?>" value="<?php echo $instance['googleplus']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'pinterest' ); ?>"><?php _e('Pinterest:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'pinterest' ); ?>" name="<?php echo $this->get_field_name( 'pinterest' ); ?>" value="<?php echo $instance['pinterest']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'instagram' ); ?>"><?php _e('Instagram:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'instagram' ); ?>" name="<?php echo $this->get_field_name( 'instagram' ); ?>" value="<?php echo $instance['instagram']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'flickr' ); ?>"><?php _e('Flickr:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'flickr' ); ?>" name="<?php echo $this->get_field_name( 'flickr' ); ?>" value="<?php echo $instance['flickr']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'youtube' ); ?>"><?php _e('Youtube:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'youtube' ); ?>" name="<?php echo $this->get_field_name( 'youtube' ); ?>" value="<?php echo $instance['youtube']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'vimeo' ); ?>"><?php _e('Vimeo:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'vimeo' ); ?>" name="<?php echo $this->get_field_name( 'vimeo' ); ?>" value="<?php echo $instance['vimeo']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'dribbble' ); ?>"><?php _e('Dribbble:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'dribbble' ); ?>" name="<?php echo $this->get_field_name( 'dribbble' ); ?>" value="<?php echo $instance['dribbble']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'behance' ); ?>"><?php _e('Behance:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'behance' ); ?>" name="<?php echo $this->get_field_name( 'behance' ); ?>" value="<?php echo $instance['behance']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'github' ); ?>"><?php _e('Github:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'github' ); ?>" name="<?php echo $this->get_field_name( 'github' ); ?>" value="<?php echo $instance['github']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'skype' ); ?>"><?php _e('Skype:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'skype' ); ?>" name="<?php echo $this->get_field_name( 'skype' ); ?>" value="<?php echo $instance['skype']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'tumblr' ); ?>"><?php _e('Tumblr:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'tumblr' ); ?>" name="<?php echo $this->get_field_name( 'tumblr' ); ?>" value="<?php echo $instance['tumblr']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'wordpress' ); ?>"><?php _e('Wordpress:','fotok'); ?></label>
			<input id="<?php echo $this->get_field_id( 'wordpress' ); ?>" name="<?php echo $this->get_field_name( 'wordpress' ); ?>" value="<?php echo $instance['wordpress']; ?>" style="width:100%;" />
		</p>

		<?php
	}

}

function register_about_fotok() {
    register_widget( 'about_fotok' );
}
add_action( 'widgets_init', 'register_about_fotok' );