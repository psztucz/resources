<?php
 /**
 * Template Name: Home Page Template
 */

get_header(); ?>

<?php if( ot_get_option('show_home_books') != 'off' ) : ?>
	<div id="books" class="section">		
		<div class="grid_6 intro">			
			<h2><?php echo ot_get_option( 'home_books_intro' ); ?></h2>			
			<?php echo wpautop( ot_get_option( 'home_books_description' ) ); ?>		
		</div>	

		<?php 
			$args = array( 'post_type' => 'book', 'posts_per_page' => 2 );
			$loop = new WP_Query( $args );
			while ( $loop->have_posts() ) :
			$loop->the_post(); 
		?>				

		<div class="grid_3 book">	
			<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('book-thumb'); ?></a>			
			<h4><a href="<?php  the_permalink(); ?>" rel="bookmark"><?php  the_title(); ?></a></h4>
			<?php the_excerpt(); ?>			
		</div>

		<?php endwhile; ?>	

		<?php wp_reset_query(); ?>

		<div class="clear"></div>
	</div>
<?php endif; ?> 
    
<?php if( ot_get_option('show_home_blogs') != 'off' ) : ?>

</div><!-- Close Container --> 

    <div id="blogs" class="section">
		<div class="container_6">		
			<div class="grid_6 intro">			
				<h2><?php echo ot_get_option( 'home_blogs_intro' ); ?></h2>
				<?php echo wpautop( ot_get_option( 'home_blogs_description' ) ); ?>		
			</div>	

			<?php 
				$args = array( 'post_type' => 'post', 'posts_per_page' => 3 );
				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) :
				$loop->the_post();
			?>  				
				<div class="grid_2 blog-post">
					<a href="<?php the_permalink(); ?>">
					<?php the_post_thumbnail('blog-thumb'); ?>
					</a>			

					<h4><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h4>
					<?php the_excerpt(); ?>		
				</div>		
			<?php endwhile; ?>	

			<div class="clear"></div>	
			
		</div>
    </div>
    
<?php endif; ?> 

<?php if( ot_get_option('show_home_author') != 'off' ) : ?>
	<div id="author" class="container_6 section">		
		<div class="grid_6">
			<img id="avatar" src="<?php  echo ot_get_option( 'home_author_image'); ?>">			
			<div class="author-description">						
				<h2><?php  echo ot_get_option( 'home_author_intro'); ?></h2>			
				<?php echo wpautop(ot_get_option( 'home_author_description')); ?>			
				<?php echo display_social_links(); ?>						
			</div>
		</div>		

		<div class="clear"></div>
	</div>
<?php endif; ?> 
		<?php get_footer(); ?>