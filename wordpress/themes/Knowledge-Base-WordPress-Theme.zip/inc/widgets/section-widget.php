<?php

/**
 * Adds Foo_Widget widget.
 */
class Olympus_KB_Widget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'apollo_kb_widget', // Base ID
			__( 'Knowledge Base Sections', 'ot-apollo' ), // Name
			array( 'description' => __( 'Displays the appropriate sections.', 'ot-apollo' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		
		if( is_tax('section') || is_singular('knowledge_base') ) {

			echo $args['before_widget'];
			if ( ! empty( $instance['title'] ) ) {
				echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ). $args['after_title'];
			}
			$this->list_sections();
			echo $args['after_widget'];
			
		}
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Sections', 'olympus-knowledge' );
		?>
		<p>
		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'ot-apollo' ); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		return $instance;
	}
	
	// First we create a function
	public function list_sections() {
		
		global $wp_query;
		
		$query_id = $wp_query->get_queried_object_id();
		
		if( is_single() ) {
			
			$term_list = wp_get_post_terms($query_id, 'section', array("fields" => "all"));
			
			if($term_list) {
				
				$term_id = $term_list['0']->parent;
				$term = get_term($term_id, 'section');
				
			} else {
				
				$term = FALSE;
				
			}

		} else {
		
			$term = get_term($query_id, 'section');
			
		}
		
		if($term) {
		 
			if( $this->has_parent($term) ) {
				$parent_id = $term->parent;
			} else {
				$parent_id = $term->term_id;
			}
			
			$args = array(
				'child_of'          => $parent_id, 
			); 

			$terms = get_terms('section', $args);

			echo '<ul>';

			foreach($terms as $id => $term) {

				// The $term is an object, so we don't need to specify the $taxonomy.
				$term_link = get_term_link( $term );

				// If there was an error, continue to the next term.
				if ( is_wp_error( $term_link ) ) {
					continue;
				}

				// We successfully got a link. Print it out.
				echo '<li class="widget-section"><a href="' . esc_url( $term_link ) . '">' . $term->name . '</a><span class="section-count">' . $term->count . '<span></li>';

			}

			echo '</ul>';
		} else {
			
		$terms = get_terms( 'section', 'order=DESC&orderby=count&hide_empty=0' );
			
				foreach($terms as $id => $term) {

					// The $term is an object, so we don't need to specify the $taxonomy.
					$term_link = get_term_link( $term );

					// If there was an error, continue to the next term.
					if ( is_wp_error( $term_link ) ) {
						continue;
					}

					// We successfully got a link. Print it out.
					echo '<li class="widget-section"><a href="' . esc_url( $term_link ) . '">' . $term->name . '</a><span class="section-count">' . $term->count . '</span></li>';

			
		} 
		
	}
	}
	public function has_parent($term) {
		
		if( $term->parent == 0) {
			return FALSE;
		} else {
			return TRUE;
	}
			
	}

} // class Foo_Widget

// register Foo_Widget widget
function register_olympus_kb_widget() {
    register_widget( 'Olympus_KB_Widget' );
}
add_action( 'widgets_init', 'register_olympus_kb_widget' );