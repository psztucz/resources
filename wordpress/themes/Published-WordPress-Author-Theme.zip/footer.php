<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 */
?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer" role="contentinfo">

		<div class="container_6">

			<div class=" grid_2">
				<?php dynamic_sidebar( 'footer-left' ); ?>
			</div><!-- .site-info -->

			<div class="grid_2">
				<?php dynamic_sidebar( 'footer-middle' ); ?>
			</div><!-- .site-info -->
	
			<div class="grid_2">
				<?php dynamic_sidebar( 'footer-right' ); ?>
			</div><!-- .site-info -->
	
			<div class="site-info grid_6">
				<p>Powered by the <a href="http://crtv.mk/iseb">Published Theme</a>.</p>
				<a class="back-to-top" href="#"><img src="<?php echo get_stylesheet_directory_uri() ?>/img/arrow-up.png" alt="Back to Top!" title="Back to Top!"/></a>
			</div><!-- .site-info -->

		</div>	
	</footer><!-- #colophon -->

	</div><!-- #page -->

<?php wp_footer(); ?>

<?php echo ot_get_option('analytics_code'); ?>

</body>
</html>

