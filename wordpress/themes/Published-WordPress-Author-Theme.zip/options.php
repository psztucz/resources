<?php /**
 * Initialize the options before anything else. 
 */
add_action( 'admin_init', 'custom_theme_options', 1 );

/**
 * Build the custom settings & update OptionTree.
 */
function custom_theme_options() {
  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( 'option_tree_settings', array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  $custom_settings = array(
    'contextual_help' => array(
      'content'       => array( 
        array(
          'id'        => 'general_help',
          'title'     => 'General Settings',
          'content'   => '<p>Interesting</p>'
        ),				
		  
		array(
			'id'        => 'home_help',
			'title'     => 'Home Settings',
			'content'   => '<p>Help content goes here!</p>'
		),				
		  
		array(
          'id'        => 'design_help',
          'title'     => 'Design Settings',
          'content'   => '<p>Help content goes here!</p>'
        ),		
		  
		array(
          'id'        => 'typography_help',
          'title'     => 'Typography Settings',
          'content'   => '<p>Help content goes here!</p>'
        ),				
		  
		 array(
			 'id'        => 'social_help',
			 'title'     => 'Social Settings',
			 'content'   => '<p>Help content goes here!</p>'
		 )
		  
      ),
      'sidebar'       => '<p>Sidebar content goes here!</p>',
    ),
    'sections'        => array(
		array(
			'id'          => 'general',
			'title'       => 'General Settings'
		),
		array(
			'id'          => 'home', 
			'title'       => 'Homepage Settings'
		),	  
		array(
			'id'          => 'design',
			'title'       => 'Design Settings'
		),	  
		array(
			'id'          => 'typography',
			'title'       => 'Typography Settings'
		),

		array(
			'id'          => 'social',
			'title'       => 'Social Settings'
		),
		
		array(
			'id'          => 'retailer_options',
			'title'       => __( 'Retailer Options', 'published' )
		)
    ),
    'settings'        => array(
	  array(
        'id'          => 'logo_upload',
        'label'       => 'Custom Logo',
        'desc'        => 'Upload your logo.',
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'favicon_upload',
        'label'       => 'Custom Favicon',
        'desc'        => 'Upload your favicon.',
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),	  		 
		
		array(
		  'id'          => 'home_header_intro',
		  'label'       => 'Homepage Header Introduction',
		  'desc'        => 'This will be shown on just the homepage.',
		  'std'         => 'Configure Your Header Intro Under Theme Options &rarr; Homepage Settings.',
		  'type'        => 'text',
		  'section'     => 'home',
		  'rows'        => '',
		  'post_type'   => '',
		  'taxonomy'    => '',
		  'min_max_step'=> '',
		  'class'       => '',
		  'condition'   => '',
		  'operator'    => 'and'      ),
		
		array(
			'id'          => 'header_intro',
			'label'       => 'Header Introduction',
			'desc'        => 'This will be shown on all pages except home.',
			'std'         => 'This area is perfect for placing a link to your <a href="">Newsletter</a> or <a href="">Sales Page</a>.',
			'type'        => 'text',
			'section'     => 'general',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '', 
			'condition'   => '', 
			'operator'    => 'and'
		),	  
      
      array(
        'id'          => 'excerpt_select',
        'label'       => 'Blog Content',
        'desc'        => 'Show full posts or excerpts on the blog?',
        'std'         => '',
        'type'        => 'select',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array( 
          array(
            'value'       => 'excerpts',
            'label'       => 'Excerpts',
            'src'         => ''
          ),
          array(
            'value'       => 'full',
            'label'       => 'Full Content',
            'src'         => ''
          )
        )
      ),
        
      array(
        'id'          => 'custom_css',
        'label'       => 'Custom CSS',
        'desc'        => 'Place any CSS code here.',
        'std'         => '',
        'type'        => 'css',
        'section'     => 'general',
        'rows'        => '15',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'analytics_code',
        'label'       => 'Analytics Code',
        'desc'        => 'Place any tracking/analytics code here.',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'general',
        'rows'        => '15',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),	  

      array(
        'id'          => 'header_color',
        'label'       => 'Primary Header Color',
        'desc'        => 'Choose a color for your header.',
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'design',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'accent_color',
        'label'       => 'Accent Color',
        'desc'        => 'The accent color controls the color of all hyperlinks and buttons.',
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'design',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'footer_color',
        'label'       => 'Footer Color',
        'desc'        => 'Choose a color for your footer.',
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'design',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'paragraph_font',
        'label'       => 'Base Font Style',
        'desc'        => 'Overwrite the default typography.',
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'title_font',
        'label'       => 'Post Title Font Style',
        'desc'        => 'Overwrite the default heading typography.',
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),	  
	  array(
        'id'          => 'sidebar_heading',
        'label'       => 'Sidebar Heading Font Style',
        'desc'        => 'Overwrite the default sidebar typography.',
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'sidebar_font',
        'label'       => 'Sidebar Font Style',
        'desc'        => 'Overwrite the default sidebar typography.',
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),	  
	  array(
        'id'          => 'navigation_font',
        'label'       => 'Navigation Font Style',
        'desc'        => 'Overwrite the default navigation typography.',
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
		array(
			'id'          => 'home_books_intro',
			'label'       => 'Books Introduction Title',
			'desc'        => 'A title to introduce your books.',
			'std'         => 'Recently Published Books.',
			'type'        => 'text',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'      ),
		
		array(
			'id'          => 'home_books_description',
			'label'       => 'Books Introduction',
			'desc'        => '100 words or less introducing your books.',
			'std'         => '',
			'type'        => 'textarea-simple',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '', 
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'      ),
		
		array(
			'id'          => 'home_blogs_intro',
			'label'       => 'Blog Introduction Title',
			'desc'        => 'A title to introduce your log posts.',
			'std'         => 'Latest Blog Posts.',
			'type'        => 'text',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'home_blogs_description',
			'label'       => 'Blog Introduction',
			'desc'        => '100 words or less introducing your blog posts.',
			'std'         => '',
			'type'        => 'textarea-simple',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'home_author_image',
			'label'       => 'Author Image',
			'desc'        => 'This will automatically be transformed into a circular image. <br><br>Recommended size: 150px x 150px',
			'std'         => '',
			'type'        => 'upload',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '', 
			'min_max_step'=> '', 
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'home_author_intro', 
			'label'       => 'Author Introduction Title',
			'desc'        => 'The title of your introduction.',
			'std'         => 'About the Author', 
			'type'        => 'text',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '', 
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'home_author_description',
			'label'       => 'Author Introduction',
			'desc'        => 'Use this area to introduce yourself and your work.',
			'std'         => '',
			'type'        => 'textarea-simple',
			'section'     => 'home',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'twitter_url',
			'label'       => 'Twitter URL',
			'desc'        => '',
			'std'         => 'http://', 
			'type'        => 'text', 
			'section'     => 'social',
			'rows'        => '', 
			'post_type'   => '',  
			'taxonomy'    => '',    
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'facebook_url',
			'label'       => 'Facebook URL',
			'desc'        => '',
			'std'         => 'http://',
			'type'        => 'text',
			'section'     => 'social',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'google_url',
			'label'       => 'Google+ URL',
			'desc'        => '',
			'std'         => 'http://',
			'type'        => 'text', 
			'section'     => 'social',
			'rows'        => '', 
			'post_type'   => '', 
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'pinterest_url',
			'label'       => 'Pinterest URL',
			'desc'        => '',
			'std'         => 'http://',
			'type'        => 'text',
			'section'     => 'social',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(        'id'          => 'linkedin_url',
			  'label'       => 'LinkedIn URL',
			  'desc'        => '',
			  'std'         => 'http://',
			  'type'        => 'text',
			  'section'     => 'social',
			  'rows'        => '',
			  'post_type'   => '',
			  'taxonomy'    => '',
			  'min_max_step'=> '',
			  'class'       => '',
			  'condition'   => '',
			  'operator'    => 'and'
			 ),
		array(
			'id'          => 'youtube_url',
			'label'       => 'YouTube URL',
			'desc'        => '', 
			'std'         => 'http://',
			'type'        => 'text',
			'section'     => 'social',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'instagram_url',
			'label'       => 'Instagram URL',
			'desc'        => '',
			'std'         => 'http://', 
			'type'        => 'text',
			'section'     => 'social',
			'rows'        => '', 
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '', 
			'operator'    => 'and'
		),
		
		array(
			'id'          => 'rss_url',
			'label'       => 'RSS URL',
			'desc'        => '',
			'std'         => 'http://',
			'type'        => 'text',
			'section'     => 'social',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and'
		),

	   array(
			'id'          => 'retailers',
			'label'       => __( 'Books Retailers', 'ot-author' ),
			'desc'        => __( 'Add the locations your books are available.', 'ot-author'),
			'std'         => '',
			'type'        => 'list-item',
			'section'     => 'retailer_options',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '',
			'class'       => '',
			'condition'   => '',
			'operator'    => 'and',
			'settings'    => array( 
			  array(
				'id'          => 'retailer_name',
				'label'       => __( 'Retailer Name', 'ot-author' ),
				'desc'        => __( 'This will be shown on your book pages.', 'ot-author'),
				'std'         => '',
				'type'        => 'text',
				'post_type'   => '',
				'taxonomy'    => '',
				'min_max_step'=> '',
				'class'       => '',
				'condition'   => '',
				'operator'    => 'and'
			  ),
			   array(
				'id'          => 'retailer_id',
				'label'       => __( 'Retailer ID', 'ot-author' ),
				'desc'        => __( 'For backend use only. Choose a lowercase id consisting only of letters. Example: amazon', 'ot-author'),
				'std'         => '',
				'type'        => 'text',
				'post_type'   => '',
				'taxonomy'    => '',
				'min_max_step'=> '',
				'class'       => '',
				'condition'   => '',
				'operator'    => 'and'
			  )
			) 
		  )		
    )
  );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( 'option_tree_settings', $custom_settings ); 
  }
  
}