<?php
/**
 * The template for displaying all articles within the knowledge base custom post type.
 *
 * @package apollo
 */

get_header(); ?>

	<div id="primary" class="content-area knowledge col-8-12">
		<main id="main" class="site-main" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

			<?php get_template_part( 'content', 'article' ); ?>

		<?php endwhile; // end of the loop. ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_sidebar('knowledge'); ?>
<?php get_footer(); ?>
