<?php
/**
 * Template Name: Archives Page
 */

get_header(); ?>

	<div id="primary" class="grid_4 content-area full-width">
		<main id="main" class="site-main" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<h1 class="entry-title"><?php the_title(); ?></h1>
	</header><!-- .entry-header -->

	<div class="entry-content">
		
<?php the_content(); ?>

<div id="archives-category">
<h4><?php _e( 'By Category', 'published' ); ?></h4>
<ul>
<?php wp_list_categories( 'title_li=&hierarchical=0&show_count=0' ); ?>
</ul>
</div>

<div id="archives-monthly">
<h4><?php _e( 'By Date', 'published' ); ?></h4>
<ul>
<?php wp_get_archives(); ?></ul>
</div>
<div class="clear"></div>
<div id="archives-all">
<h4><?php _e( 'All Blog Posts', 'published' ); ?></h4>
<ul><?php wp_get_archives('show_post_count=1&type=postbypost'); ?></ul>
</div>

<div id="archives-tag">
<h4><?php _e( 'By Tag', 'published' ); ?></h4>
<div class="tagcloud">
<?php wp_tag_cloud(); ?>
</div>

	</div><!-- .entry-content -->
</article><!-- #post-## -->
			<?php endwhile; // end of the loop. ?>

		</main><!-- #main -->
	</div><!-- #primary -->
<?php get_footer(); ?>