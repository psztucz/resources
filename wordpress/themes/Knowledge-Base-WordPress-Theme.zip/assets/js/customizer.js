/**
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */

( function( $ ) {
	
	"use strict";
	
	// Site title and description.
	wp.customize( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );
	wp.customize( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$( '.site-description' ).text( to );
		} );
	} );
	
	wp.customize( 'header_bg', function( value ) {
		value.bind( function( to ) {
			$( '.site-header' ).css( 'background', to );
		} );
	} );
	
	wp.customize( 'logo_color', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a, .site-description' ).css( 'color', to );
		} );
	} );	
	
	wp.customize( 'nav_color', function( value ) {
		value.bind( function( to ) {
			$( '.main-navigation a' ).css( 'color', to );
		} );
	} );
	
	wp.customize( 'hero_headline', function( value ) {
		value.bind( function( to ) {
			$( '.hero-title' ).text( to );
		} );
	} );
	
	wp.customize( 'hero_text', function( value ) {
		value.bind( function( to ) {
			$( '.hero-text' ).text( to );
		} );
	} );	
	
	wp.customize( 'hero_bg', function( value ) {
		value.bind( function( to ) {
			$( '.hero' ).css( 'background', to );
		} );
	} );	
	
	wp.customize( 'hero_image', function( value ) {
		value.bind( function( to ) {
			$( '.video-background' ).css( 'background-image', 'url("' + to + '")' );
		} );
	} );	
	
	wp.customize( 'callout_bg', function( value ) {
		value.bind( function( to ) {
			$( '.callout' ).css( 'background', to );
		} );
	} );

	wp.customize( 'callout_text', function( value ) {
		value.bind( function( to ) {
			$( '.callout-text' ).text( to );
		} );
	} );	
	
	wp.customize( 'callout_button_text', function( value ) {
		value.bind( function( to ) {
			$( '.callout-button' ).text( to );
		} );
	} );
	
	wp.customize( 'footer_bg', function( value ) {
		value.bind( function( to ) {
			$( '.footer' ).css( 'background', to );
		} );
	} );
	
	wp.customize( 'sub_footer_bg', function( value ) {
		value.bind( function( to ) {
			$( '.sub-footer' ).css( 'background', to );
		} );
	} );	

	wp.customize( 'link_color', function( value ) {
		value.bind( function( to ) {
			$( '.content-area a' ).css( 'color', to );
		} );
	} );		
	
	wp.customize( 'button_color', function( value ) {
		value.bind( function( to ) {
			$( '.apollo-button' ).css( 'color', to );
		} );
	} );	
	
	wp.customize( 'button_bg', function( value ) {
		value.bind( function( to ) {
			$( '.apollo-button' ).css( 'background', to );
		} );
	} );		
	

} )( jQuery );