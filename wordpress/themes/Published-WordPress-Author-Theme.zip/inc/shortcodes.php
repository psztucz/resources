<?php

function half_column_shortcode( $atts, $content = null ) {
	return '<div class="one_half">' . $content . '</div>';
}
add_shortcode( 'one_half', 'half_column_shortcode' );	

function last_half_column_shortcode( $atts, $content = null ) {
	return '<div class="one_half last_column">' . $content . '</div><div class="clear"></div>';
}
add_shortcode( 'one_half_last', 'last_half_column_shortcode' );

function third_column_shortcode( $atts, $content = null ) {
	return '<div class="one_third">' . $content . '</div>';
}
add_shortcode( 'one_third', 'third_column_shortcode' );	

function last_third_column_shortcode( $atts, $content = null ) {
	return '<div class="one_third last_column">' . $content . '</div><div class="clear"></div>';
}
add_shortcode( 'one_third_last', 'last_third_column_shortcode' );	

function quarter_column_shortcode( $atts, $content = null ) {
	return '<div class="one_quarter">' . $content . '</div>';
}
add_shortcode( 'one_quarter', 'quarter_column_shortcode' );	

function last_quarter_column_shortcode( $atts, $content = null ) {
	return '<div class="one_quarter last_column">' . $content . '</div><div class="clear"></div>';
}
add_shortcode( 'one_quarter_last', 'last_quarter_column_shortcode' );

function sixth_column_shortcode( $atts, $content = null ) {
	return '<div class="one_sixth">' . $content . '</div>';
}
add_shortcode( 'one_sixth', 'sixth_column_shortcode' );	

function last_sixth_column_shortcode( $atts, $content = null ) {
	return '<div class="one_sixth last_column">' . $content . '</div><div class="clear"></div>';
}
add_shortcode( 'one_sixth_last', 'last_sixth_column_shortcode' );	

function published_button_shortcode( $atts, $content = null ) {
	$a = shortcode_atts( array(
        'text' => '',
        'url' => '',
		'size' => '',
    ), $atts );
	return '<p><a href="' . $a['url'] . '" class="button ' . $a['size'] . '">' . $a['text'] . '</a></p>';
}
add_shortcode( 'published_button', 'published_button_shortcode' );

function intro_shortcode( $atts, $content = null ) {
	return '<p class="intro">' . $content . '</p>';
}

add_shortcode( 'intro', 'intro_shortcode' );

function html_shortcode( $atts, $content = null ) {
	return '<pre class="html">' . $content . '</pre>';
}

add_shortcode( 'html_code', 'html_shortcode' );	

function css_shortcode( $atts, $content = null ) {
	return '<pre class="css">' . $content . '</pre>';
}

add_shortcode( 'css_code', 'css_shortcode' );

function js_shortcode( $atts, $content = null ) {
	return '<pre class="js">' . $content . '</pre>';
}

add_shortcode( 'js_code', 'js_shortcode' );

function social_shortcode( $atts, $content = null ) {
	return display_social_links();
}

add_shortcode( 'social_icons', 'social_shortcode' );	