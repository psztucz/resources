<?php

/**
 * Initialize the custom Meta Boxes. 
 */
add_action( 'admin_init', 'base_meta_boxes' );

/**
 * Meta Boxes demo code.
 *
 * You can find all the available option types in demo-theme-options.php. 
 *
 * @return    void
 * @since     2.0
 */
function base_meta_boxes() {
  
  $retailers = get_retailers();
	
	
  /**
   * Create a custom meta boxes array that we pass to 
   * the OptionTree Meta Box API Class.
   */
  $post_image_slider = array(
    'id'          => 'contact_meta_box',
    'title'       => __( 'Contact Form Settings', 'published' ),
    'desc'        => 'These settings can only be used when the contact template is active.',
    'pages'       => array( 'page' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(

	     array(
        'label'       => 'Google Maps Code',
        'id'          => 'published_map_code',
        'desc'        => 'Place your map embed here.',
		'std'         => '',
        'type'        => 'textarea-simple',
        'class'       => '',
      ),
	  
	  	array(
        'label'       => 'Address and Contact Info',
        'id'          => 'published_contact',
        'desc'        => 'Place your contact information here.',
		'std'         => '',
        'type'        => 'textarea',
        'class'       => '',
      ),
	
    )
  );
  
   $formats_meta_box = array(
    'id'          => 'formats_meta_box',
    'title'       => __( 'Video & Audio Settings', 'published' ),
    'desc'        => 'Remember to select the post format you would like to use from the list on the right.',
    'pages'       => array( 'post' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(



      array(
        'label'       => 'Video/Audio Code',
        'id'          => 'base_video_code',
        'desc'        => 'Place your video or audio embed code here.',
		'std'         => '',
        'type'        => 'textarea',
        'class'       => '',
      )
    )
  );
  
   $books_meta_box = array(
    'id'          => 'url_meta_box',
    'title'       => __( 'Purchase URLs', 'published' ),
    'desc'        => 'Enter the URLs where your book can be purchased below.',
    'pages'       => array( 'book' ),
    'context'     => 'normal',
    'priority'    => 'low',
    'fields'      => array(


    )
  );
  

	foreach($retailers as $id => $name) {

		$books_meta_box['fields'][] = array(
					'label'       => $name.' URL',
					'id'          => 'published_'.$id.'_url',
					'desc'        => 'Place your '.$name.' link here.',
					'std'         => 'http://',
					'type'        => 'text',
					'class'       => '',
		);

	}		
			
	
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  if ( function_exists( 'ot_register_meta_box' ) )
    ot_register_meta_box( $post_image_slider );
    ot_register_meta_box( $formats_meta_box );
    ot_register_meta_box( $books_meta_box );

}