<?php
/**
 * Template Name: Home with Header Image
 *
 * @package fotok
 * @since fotok 1.0
 */

get_header(); ?>

	<?php if ( get_header_image() ) : ?>
	<div class="site-right-image">
		<img src="<?php header_image(); ?>" width="<?php echo get_custom_header()->width; ?>" height="<?php echo get_custom_header()->height; ?>" alt="">
	</div>
	<?php endif; // End header image check. ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', 'page' ); ?>

				<?php
					// If comments are open or we have at least one comment, load up the comment template
					if ( comments_open() || '0' != get_comments_number() ) :
						comments_template();
					endif;
				?>

			<?php endwhile; // end of the loop. ?>

		</main><!-- #main -->
	</div><!-- #primary -->

	<?php if ( is_active_sidebar( 'home-sidebar-1' ) ) : ?>
		<?php dynamic_sidebar( 'home-sidebar-1' ); ?>
	<?php endif; ?>

<?php get_footer(); ?>
