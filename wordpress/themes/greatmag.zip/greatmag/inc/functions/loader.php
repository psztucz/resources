<?php

/**
 * Load function files
 *
 * @package Greatmag
 */


require get_template_directory() . '/inc/functions/functions-header.php';
require get_template_directory() . '/inc/functions/functions-footer.php';
require get_template_directory() . '/inc/functions/functions-blog.php';