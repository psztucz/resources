Fotok
===============================

For a detailed theme documentation: http://pankogut.com/wordpress-themes/fotok

Support Forum: http://support.pankogut.com

===============================

Version 1.0
===============================
- Fotok theme release