<div class="author-box clearfix">

	<?php if ( is_active_sidebar( 'after-post' ) ) : ?>

		<?php dynamic_sidebar( 'after-post' ); ?>

	<?php else : ?>

		<div class="author-image">
			<?php echo get_avatar( get_the_author_meta('email') , 90 ); ?>
		</div><!-- .author-image -->

		<div class="author-info">

			<?php if( is_author() ) : ?>

				<h1 class="author-name">
					<?php the_author_link(); ?>
				</h1>

			<?php else: ?>

				<h3 class="author-name">
					<?php the_author_posts_link(); ?>
				</h3>

			<?php endif; ?>

		<p class="author-description">
			<?php echo the_author_meta('description'); ?>
		</p>
			
		</div><!-- .author-info -->

	<?php endif; ?>

</div><!-- .author-box -->