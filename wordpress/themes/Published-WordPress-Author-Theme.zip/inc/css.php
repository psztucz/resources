<?php


add_action('wp_footer', 'custom_stylesheet_content');

function custom_stylesheet_content() {

	$custom_css = ot_get_option( 'custom_css');

	$header_color = ot_get_option( 'header_color'); 
	$accent_color = ot_get_option( 'accent_color');
	$footer_color = ot_get_option( 'footer_color');

	$paragraph_font = ot_get_option( 'paragraph_font');
	$title_font = ot_get_option( 'title_font'); 
	$sidebar_heading = ot_get_option( 'sidebar_heading');
	$sidebar_font = ot_get_option( 'sidebar_font');
	$navigation_font = ot_get_option( 'navigation_font');

	
 ?>
 
 <style type="text/css">

 <?php 
 
 if ( $header_color != '' ) { echo '#masthead, .home #below-header {background:'.$header_color.'}'; } 
 if ( $accent_color != '' ) { echo '
 a, #below-header h2 a {color:'.$accent_color.'}
 a:hover {color:'.adjust_brighness($accent_color,'-50').'}
 .button, .flexslider .flex-next:hover, .flexslider .flex-prev:hover, .tagcloud a, .back-to-top img:hover {background-color:'.$accent_color.';} .button:hover, .tagcloud a:hover { background:'.adjust_brighness($accent_color,'-50').'}'; } 
 if ( $footer_color != '' ) { echo '.site-footer {background:'.$footer_color.'}'; } 
 
ot_generate_font_css('body', 'paragraph_font');      
ot_generate_font_css('h1, h2, h3, h4, h5, h6, h1 a, h2 a, h3 a, h4 a, h5 a, h6 a', 'title_font');      
ot_generate_font_css('h4.widget-title', 'sidebar_heading');      
ot_generate_font_css('#secondary', 'sidebar_font');      
ot_generate_font_css('#site-navigation ul li a', 'navigation_font');      

 
  echo $custom_css; 
 
  echo '</style>';
      
 } 
	 
function ot_generate_font_css($type, $option_name) {
	  $font_settings = ot_get_option($option_name);
	
	  if ( ! empty( $font_settings ) ) {
		echo $type.' { ';
		  foreach ($font_settings as $setting => $value) {
	
				$setting = str_replace('font-color', 'color', $setting);
				$value = str_replace('_', ' ', $value);
	
			  if($value) {
				  echo $setting . ':' . $value . ';';
			  }
		  }
     	echo ' } ';
	  }
}

	 ?>